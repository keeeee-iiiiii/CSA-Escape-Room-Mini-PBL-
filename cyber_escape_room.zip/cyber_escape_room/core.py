# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 16:13:20 2026

@author: keisy
"""

