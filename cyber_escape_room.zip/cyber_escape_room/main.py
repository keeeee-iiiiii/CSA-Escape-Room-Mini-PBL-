import asyncio
import time
import random
import flet as ft
import os
from datetime import datetime

W, H = 960, 540 # ukuran layar game (pixel)
K = 0.5         # skala: koordinat desain 1920x1080 menjadi layar 960x540
# Ubah ke True setelah file font ditaruh di assets/fonts
PAKAI_FONT = True

TIPS = [
    "Jangan pernah membagikan kode OTP kepada siapa pun.", 
    "Gunakan password panjang dan unik untuk setiap akun.", 
    "Periksa alamat pengirim sebelum mengeklik tautan di email atau pesan.", 
    "Bandingkan hash file unduhan dengan hash resmi untuk memastikan file tidak berubah.", 
    "Jika perangkatmu terkena serangan, segera putuskan dari jaringan dan laporkan.", 
    "Cek izin aplikasi. Tolak izin yang tidak sesuai dengan fungsinya.", 
    "Aktifkan verifikasi dua langkah (MFA) agar akunmu lebih aman.", 
    "Pesan yang membuatmu panik dan menyuruh bertindak cepat sering kali phishing.", 
    "Batasi permission file penting agar tidak sembarang orang bisa mengubahnya.",
    "Catat kronologi insiden. Itu bahan evaluasi agar kejadian serupa tidak terulang.",
 ]

DURASI = 6.0                           # lama loading (detik)
JUMLAH_BATANG = 16                     # jumlah batang hijau di dalam bingkai
BATANG_KIRI, BATANG_ATAS = 512,543        
BATANG_LEBAR, BATANG_TINGGI = 48, 64
JARAK_BATANG = 58.2                    # jarang dari satu batang ke batang berikutnya
SPRITE, SPRITE_ATAS = 110, 412         # ukuran dan tinggi karakter kecil
TIPS_KIRI, TIPS_TENGAH_Y = 200, 1032   # posisi teks tips
GARIS = 2                              # tebal garis hitam di pinggir teks tips
UKURAN_TIPS = 10                       # ukuran teks tips (10 = semua tips muat)
BASE = os.path.dirname(os.path.abspath(__file__))

# ---------- PENGATURAN ROOM 1 (koordinat desain 1920x1080) ----------
RUANG = "Room 1"                       # nama folder gambar ruangan di dalam assets
KAR_UKURAN = 360                       # ukuran gambar karakter
KAR_MULAI = (900, 830)                 # posisi awal: (x tengah badan, y kaki)
LANGKAH = 24                           # jarak satu kali menekan panah
KAKI_LEBAR, KAKI_TINGGI = 130, 40       # kotak kaki karakter (dipakai untuk tabrakan)
LANTAI = (20, 717, 1900, 920)          # batas lantai yang boleh diinjak: kiri, atas, kanan, bawah
BAGIAN_BAWAH = {                       # benda penghalang: bagian bawah benda yang menghalangi (1.0 = seluruhnya)
    "kardus_room1.png": 0.35,
    "rak_buku_room1.png": 0.12,
    "pot_bunga_room1.png": 0.22,
    "meja_depan_room1.png": 0.33,
}
AREA_LAPTOP = (1135, 450, 1495, 768)   # kotak laptop: kiri, atas, kanan, bawah
JARAK_LAPTOP = 150                     # seberapa dekat karakter harus berdiri dari laptop
TOMBOL_BUKA = ("e", "enter", " ")      # tombol membuka/menutup laptop (E, Enter, atau Spasi)
AWAL_DETIK = 0.6       # toleransi setelah tekan pertama (menunggu jeda awal key repeat Windows)
LEPAS_DETIK = 0.2      # setelah sinyal ulang datang, tanpa sinyal selama ini = dianggap dilepas
JEDA_TAHAN = 0.8       # sinyal tombol yang sama dalam jeda ini dianggap tombol masih ditahan
KECEPATAN = 420        # kecepatan jalan (piksel desain per detik)
BAYANG_LEBAR, BAYANG_TINGGI = 185, 44   # ukuran bayangan lonjong di kaki karakter
BAYANG_GESER = 12      # naik/turun bayangan (makin besar = makin ke atas)
DEBUG_KOTAK = False                    # True = tampilkan kotak merah penghalang; ubah ke False kalau sudah pas

# ---------- PENGATURAN NYAWA (HP), POIN, DAN PINTU ----------
NYAWA_MAKS = 3                         # jumlah hati
POIN_BENAR = 20                        # poin ruangan bila lulus (benar >= MINIMAL_BENAR)
POIN_SALAH = 15                        # poin ruangan bila gagal (20 dikurangi 5) + kehilangan 1 nyawa
MINIMAL_BENAR = 2                      # benar >= 2 dari 4 pertanyaan = lulus
KEDIP_JEDA = 0.3                       # lama hati merah / putih saat berkedip (detik)
FILE_HATI_MERAH = "hati_merah.png"     # simpan di folder assets
FILE_HATI_PUTIH = "hati_putih.png"     # simpan di folder assets
HATI_HUD = (AREA_LAPTOP[2] - AREA_LAPTOP[0]) / 4   # ukuran satu hati di pojok kiri atas = seperempat lebar laptop (koordinat desain)
HATI_HUD_KIRI, HATI_HUD_ATAS, HATI_HUD_JARAK = 20, 20, 8   # posisi dan jarak antar hati (koordinat desain)
FILE_PINTU_TERBUKA = "pintu_terbuka_room1.png"      # simpan di assets/Room 1
AREA_PINTU = (1640, 700, 1920, 830)    # kalau kaki karakter masuk kotak ini (kiri, atas, kanan, bawah) = masuk pintu

FILE_DESKTOP = "desktop_laptop.jpeg"    # gambar desktop laptop (simpan di folder assets)
ICON_JIMAIL = (64, 36, 170, 200)        # area klik ikon Jimail: kiri, atas, lebar, tinggi (koordinat desain 1920x1080)
JAM = (1574, 966, 346, 114)              # kotak jam hijau: kiri, atas, lebar, tinggi (menutupi jam di gambar)
 
# warna tampilan Jimail
J_BG, J_PANEL, J_GARIS = "#171C4A", "#0C1236", "#4C5FC8"
J_TEKS, J_ABU, J_AKTIF = "#EAF0FF", "#9AA6E0", "#3B4A9C"

# warna halaman poin (tema Gmail terang)
P_BG, P_KARTU, P_GARIS = "#F6F8FC", "#FFFFFF", "#DADCE0"
P_TEKS, P_ABU = "#202124", "#5F6368"
P_BENAR, P_SALAH = "#1E8E3E", "#C5221F"
# kotak alasan jawaban: latar biru dongker, teks terang
P_ALASAN_BG, P_ALASAN_GARIS = "#0A1F44", "#2F4B8F"
P_ALASAN_JUDUL, P_ALASAN_ISI = "#EAF0FF", "#B8C4EC"
P_ALASAN_BENAR, P_ALASAN_SALAH = "#5FE08A", "#FF8A8A"

# animasi masuk pintu (detik)
FADE_KE_PUTIH = 1.2                    # fade ruangan -> putih
TAHAN_PUTIH = 5.0                      # lama layar putih "YOU ESCAPE THE ROOM"
FADE_DARI_PUTIH = 1.2                  # fade putih -> ruangan berikutnya
 
# 4 email: dua phishing, dua asli. Ubah teks/waktu di sini kapan saja.
EMAIL = [
    {
        "nama": "Sistem Akademik Kampus",
        "alamat": "admin-siakad@universitas-kemdikbud-id.com",
        "subjek": "[URGENT] Akun SIAKAD Anda Ditangguhkan - Segera Verifikasi!",
        "waktu": "08.15",
        "isi": ("Halo Mahasiswa,\n\nKami mendeteksi adanya aktivitas login mencurigakan pada akun Sistem "
                "Informasi Akademik (SIAKAD) Anda dari perangkat di luar kota. Untuk keamanan, akun Anda "
                "telah ditangguhkan sementara. Harap lakukan verifikasi ulang dalam waktu 24 jam agar Anda "
                "tetap bisa mengakses jadwal UTS. Klik link berikut untuk verifikasi:"),
        "tautan": "Verifikasi Akun SIAKAD Disini",
        "tujuan": "http://siakad-univ-verification.net",
        "phishing": True,
        "alasan": ["Urgensi berlebihan: akun diancam hangus dalam 24 jam menjelang UTS.",
                   "Domain salah: email resmi kampus memakai format nama-univ.ac.id, bukan .com atau .net."],
    },
    {
        "nama": "Kampus Merdeka",
        "alamat": "no-reply@kampusmerdeka.kemdikbud.go.id",
        "subjek": "Undangan Wawancara Program Magang Merdeka - Batch 2027",
        "waktu": "09.40",
        "isi": ("Yth. Pendaftar Program Magang Merdeka,\n\nBerdasarkan seleksi berkas yang telah dilakukan, "
                "Anda dinyatakan lolos ke tahap wawancara. Jadwal wawancara dan detail teknis dapat Anda "
                "lihat langsung dengan masuk ke dasbor akun resmi Kampus Merdeka Anda. Kami tidak memungut "
                "biaya apa pun dalam proses ini."),
        "tautan": "Dasbor Kampus Merdeka",
        "tujuan": "https://kemdikbud.go.id",
        "phishing": False,
        "alasan": ["Domain resmi: memakai ekstensi .go.id (pemerintah).",
                   "Tidak meminta data sensitif: pemain tidak disuruh klik link aneh, melainkan diminta "
                   "mengecek dasbor resmi secara mandiri."],
    },
    {
        "nama": "Komite Beasiswa Pendidikan",
        "alamat": "info@beasiswa-mahasiswa-indonesia.org",
        "subjek": "Pemberitahuan: Dana Bantuan UKT Semester Ganjil 2026/2027",
        "waktu": "10.05",
        "isi": ("Selamat! Anda terpilih sebagai salah satu penerima bantuan subsidi UKT sebesar Rp2.500.000 "
                "untuk semester ini. Dana akan langsung ditransfer ke rekening Anda. Untuk mencairkan dana "
                "tersebut, silakan daftarkan nomor kartu debit/kredit beserta kode CVV Anda melalui formulir "
                "digital di bawah ini:"),
        "tautan": "Formulir Pencairan Dana UKT",
        "tujuan": "https://forms.gle",
        "phishing": True,
        "alasan": ["Terlalu bagus untuk jadi nyata: mendapat beasiswa tanpa pernah mendaftar.",
                   "Meminta data finansial rahasia: nomor kartu dan kode CVV tidak boleh dibagikan kepada siapa pun."],
    },
    {
        "nama": "Perpustakaan Pusat",
        "alamat": "library@univ-kamu.ac.id",
        "subjek": "[Perpustakaan Pusat] Pengingat Pengembalian Buku Telat",
        "waktu": "11.20",
        "isi": ("Halo [Nama Pemain],\n\nSistem kami mencatat bahwa Anda belum mengembalikan buku berjudul "
                "'Pengantar Teknologi Informasi' yang jatuh tempo pada 18 November 2026. Saat ini denda "
                "keterlambatan Anda adalah sebesar Rp10.000. Harap segera mengembalikan buku ke loket "
                "perpustakaan utama pada jam kerja."),
        "tautan": None,
        "tujuan": None,
        "phishing": False,
        "alasan": ["Informasi spesifik: menyebut judul buku dan tanggal yang jelas, bukan sapaan umum.",
                   "Instruksi fisik: penyelesaian dilakukan dengan datang ke loket perpustakaan kampus."],
    },
]
 
def jam_sekarang():
    """Jam saat ini untuk taskbar laptop, misalnya 14.05 PM."""
    n = datetime.now()
    return n.strftime("%H.%M") + (" PM" if n.hour >= 12 else " AM")

FILE_DESKTOP_WA = "desktop_laptop_wa.jpeg"   # desktop dengan ikon Wasap (skenario 2 dan 3), simpan di assets
KROM_AREA = (905, 970, 110, 100)            # area klik ikon Krom di taskbar: kiri, atas, lebar, tinggi
SKENARIO_PAKSA = None                       # isi 1, 2, atau 3 untuk mengetes satu skenario; None = acak
OTOMATIS_KE_KROM = True                    # True = setelah chat Ibu selesai, Krom langsung terbuka
JEDA_KE_KROM = 5.0
 
# ---------- SKENARIO 2: KURIR PALSU (Wasap) ----------
KURIR = {
    "nomor": "+62 812-3456-7890",
    "awal": ("Permisi kak, maaf mengganggu. Saya kurir dari ekspedisi J&X. Mau menginfokan kalau paket atas "
             "nama kakak dengan resi JX998877 hilang di gudang sortir karena banjir. Kami mau bertanggung "
             "jawab untuk ganti rugi (return uang) full sebesar nilai barang. Tolong kirimkan QR code "
             "m-banking / QRIS penerimaan bank kakak ya ke chat ini biar uangnya langsung kami transfer sekarang."),
    "babak1": ["Oh ya? Paket yang mana ya? Perasaan saya minggu ini cuma pesan casing HP di e-commerce.",
               "Lho, kok return uang pakai kirim QR code bank? Bukannya biasanya langsung minta nomor rekening atau lewat sistem e-commerce?",
               "Lewati obrolan dan langsung ambil keputusan."],
    "balas1": ["Iya betul kak, paketnya itu casing HP. Ini dari sistem kami datanya hangus jadi kami ga bisa cek "
               "detailnya, tapi yang jelas resi kakak yang hilang. Makanya kami minta QR m-banking kakak sekarang "
               "biar cepat kami ganti rugi, soalnya shift saya mau habis kak. Mohon dibantu ya.",
               "Sekarang peraturan baru dari kantor kami begitu kak, kalau pakai nomor rekening prosesnya lama 3 "
               "hari kerja. Kalau pakai QR m-banking/QRIS kakak, uangnya bisa langsung cair dalam 5 menit dari "
               "dompet digital kantor kami. Tinggal screenshoot aja bagian QR terima uang di aplikasi bank kakak "
               "terus kirim kesini."],
    "clue1": ["Penipu menjawab dengan menebak-nebak dan langsung membuat alasan mendesak agar korban panik.",
              "Penipu memutarbalikkan logika teknologi agar korban mau memberikan akses finansial."],
    "babak2": ["Saya cek di aplikasi belanja saya status paketnya masih jalan kok, belum hilang. Tolong kirim "
               "foto kartu identitas kerja (ID Card) kurir kamu dulu deh kalau mau saya percaya.",
               "Gini aja, saya urus langsung ke kantor cabang J&X terdekat di daerah saya. Nama kantor cabang "
               "kamu apa dan di mana?"],
    "balas2": ("Aduh kak, saya ini cuma niat baik mau bantu ganti rugi uang kakak pribadi, jangan dipersulit dong. "
               "Kalau kakak ga kirim QR-nya sekarang, hangus ya uang ganti ruginya! Saya anggap kakak menolak "
               "ganti rugi!"),
    "keputusan": ["Percaya dan kirim QR bank", "Tidak percaya dan blokir nomor tersebut"],
    "benar_idx": 1,
    "alasan": ["Kamu tertipu! Dengan mengirimkan QR code bank (terutama jika itu QRIS/QR transfer yang salah "
               "dipahami), penipu bisa menyalahgunakannya untuk menguras saldo atau melakukan transaksi ilegal "
               "atas namamu. Kurir resmi TIDAK PERNAH meminta data sensitif atau QR code di luar aplikasi resmi "
               "e-commerce.",
               "Keputusan tepat! Ini adalah modus phishing/scam. Jika paket hilang, pihak ekspedisi atau "
               "e-commerce akan menyelesaikan ganti rugi secara otomatis lewat saldo akun belanja milikmu di "
               "aplikasi resmi, bukan melalui chat personal dari nomor tak dikenal."],
}
 
# ---------- SKENARIO 3: CHAT IBU (Wasap) + RIWAYAT KROM ----------
IBU = {
    "nama": "Ibu <3",
    "awal": ["Kak... Tolongin Ibu sebentar nak, Ibu panik banget ini :'(",
             "Ini kok tiba-tiba akun Facebook Ibu keluar sendiri ya? Pas Ibu mau masuk lagi pakai password "
             "biasanya, katanya password-nya salah terus.",
             "Terus ini barusan ada SMS masuk ke HP Ibu, katanya ada orang dari kota lain yang mencoba login ke "
             "akun Ibu. Duh, gimana ini ya? Takutnya Facebook Ibu di-hack orang terus dipakai buat pinjam uang "
             "ke teman-teman Ibu :("],
    "pilihan": ["Tenang Bu, jangan panik dulu. Sebelum akunnya keluar sendiri, Ibu ada sempat klik link atau "
                "buka website aneh ga di HP?",
                "Lho kok bisa Bu? Ibu ada masukin password Facebook Ibu ke link pengumuman hadiah atau kupon "
                "gratisan ya baru-baru ini?"],
    "balas": ["Aduh iya kayaknya nak... Tadi siang Ibu ada ngeklik beberapa link dari grup arisan. Ada yang "
              "katanya lowongan kerja, resep kue, sama undian berhadiah gitu. Ibu pikir itu beneran dari "
              "Facebook jadi Ibu masukin aja email sama password Ibu di sana :(",
              "Ibu ga tahu mana yang asli mana yang palsu. Ini Ibu screenshoot riwayat link (URL) yang tadi "
              "siang sempat Ibu buka ya nak. Tolong kamu periksa dulu, Ibu takut salah klik lagi..."],
    "petunjuk": "Buka aplikasi Krom di taskbar bawah untuk memeriksa riwayat link Ibu.",
}
 
URL_KROM = [
    {"judul": "Facebook - Masuk atau Daftar", "url": "https://facebook.com", "waktu": "14.02", "resmi": True,
     "alasan": "Alamatnya persis facebook.com dan memakai https."},
    {"judul": "Hadiah Gratis dari Facebook! Klaim Sekarang", "url": "https://facebook-hadiah-gratis.com",
     "waktu": "13.47", "resmi": False,
     "alasan": "Domainnya facebook-hadiah-gratis.com, bukan facebook.com. Tambahan kata hadiah-gratis adalah umpan."},
    {"judul": "Facebook - Masuk atau Daftar", "url": "http://facebook-login.net", "waktu": "13.21", "resmi": False,
     "alasan": "Domainnya .net dan bukan facebook.com, serta hanya memakai http. Judul halaman bisa dipalsukan, "
               "jadi periksa alamatnya."},
    {"judul": "Facebook", "url": "https://facebook.com", "waktu": "12.55", "resmi": True,
     "alasan": "Alamatnya persis facebook.com dan memakai https."},
]
 
HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
BULAN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September",
         "Oktober", "November", "Desember"]
 
 
def tanggal_id():
    n = datetime.now()
    return f"{HARI[n.weekday()]}, {n.day} {BULAN[n.month - 1]} {n.year}"

 
def muat_penghalang():
    return list(PENGHALANG_TETAP)

PENGHALANG_TETAP = [               # kiri, atas, kanan, bawah (koordinat desain)
    (0, 676, 412, 757), 
    (410, 661, 550, 740), 
    (1050, 664, 1148, 733), 
    (1135, 621, 1495, 768)
]

def main(page: ft.Page):
    page.title = "Cypherive"
    page.bgcolor = "black"
    page.padding = 0
    
    FONT = None
    if PAKAI_FONT:
        page.fonts = {"Pixel": "fonts/PressStart2P-Regular.ttf"}
        FONT = "Pixel"
    
    # karakter yang dipilih, sisa nyawa, dan poin per ruangan (nyawa & poin tetap tersimpan antar-ruangan)
    state = {"karakter": "Cya", "nyawa": NYAWA_MAKS, "skor": {}}
    
    stage = ft.Stack(width=W, height=H)
    page.add(ft.Container(content=stage, alignment=ft.alignment.center, expand=True))
    
    def lapisan(nama):
        return ft.Image(src=nama, width=W, height=H, fit=ft.ImageFit.FILL)
    def area_klik(kiri, atas, lebar, tinggi, klik):
        return ft.Container(left=kiri * K, top=atas * K, width=lebar * K, height=tinggi * K, on_click=klik)
    
    # ---------- LAYAR 1: HOME ----------
    def home(e=None):
        page.on_keyboard_event = None
        stage.controls = [ 
            lapisan("bg_bersih.png"),
            lapisan("judul.png"),
            lapisan("tombol_menu.png"),
            area_klik(755, 470, 350, 110, loading),
            area_klik(755, 615, 490, 110, tampil_karakter),
        ]
        page.update()
    
    # ---------- LAYAR 2:PILIH KARAKTER ----------
    def pilih(nama):
       def klik(e):
           state["karakter"] = nama
           tampil_karakter()
       return klik
    def tampil_karakter(e=None):
        if state["karakter"] == "Bero":
            gambar_bero = "bero_dipilih.png"
        else:
            gambar_bero = "bero_normal.png"
            
        if state["karakter"] == "Cya":
            gambar_cya = "cya_dipilih.png"
        else:
            gambar_cya = "cya_normal.png"
        stage.controls = [
            lapisan("bg_bersih.png"),
            lapisan("judul_karakter.png"),
            lapisan("atau.png"),
            lapisan(gambar_bero),
            lapisan(gambar_cya),
            lapisan("tombol_x.png"),
            area_klik(245, 345, 525, 655, pilih("Bero")),
            area_klik(1150, 345, 530, 655, pilih("Cya")),
            area_klik(30, 33, 78, 78, home),
        ]
        page.update()
     # ---------- LAYAR 3:LOADING ----------
    def teks_garis(isi, ukuran, lebar):
        geser = [(-GARIS, -GARIS), (0, -GARIS), (GARIS, -GARIS),
                 (-GARIS, 0), (GARIS, 0),
                 (-GARIS, GARIS), (0, GARIS), (GARIS, GARIS)]
        daftar = []
        for dx, dy in geser:
            daftar.append(ft.Text(isi, size=ukuran, color="black", font_family=FONT,
                                  left=GARIS + dx, top=GARIS + dy))
        daftar.append(ft.Text(isi, size=ukuran, color="white", font_family=FONT,
                              left=GARIS, top=GARIS))
        kotak = ft.Stack(daftar, width=lebar, height=ukuran + 2 * GARIS + 6)
        return kotak, daftar 
    
    async def loading(e=None):
        # game baru (dari menu atau dari layar YOU LOSE): nyawa penuh dan poin kembali nol
        state["nyawa"] = NYAWA_MAKS
        state["skor"] = {}

# ===== A. BUAT OBJEK (batang, karakter, teks) =====
        tiga_tips = random.sample(TIPS, 3)
        batang = []
        for n in range(JUMLAH_BATANG):
            kiri = BATANG_KIRI + n * JARAK_BATANG 
            batang.append(ft.Image(src="batang_hijau.png", left=kiri * K, 
                                   top=BATANG_ATAS * K, width=BATANG_LEBAR * K, height=BATANG_TINGGI * K, 
                                   fit=ft.ImageFit.FILL, visible=False))
        nama = state["karakter"].lower()
        tengah_awal = BATANG_KIRI + BATANG_LEBAR / 2 - JARAK_BATANG
        karakter = ft.Image(src=f"loading_{nama}.png",
                            left=(tengah_awal - SPRITE /2) * K, top=SPRITE_ATAS * K,
                            width=SPRITE * K, height=SPRITE * K,
                            animate_position=100)
        kotak_tips, daftar_tips = teks_garis(tiga_tips[0], UKURAN_TIPS, 860)
            

        # ===== B. TAMPILAN LAYAR =====
        stage.controls = [
            lapisan("bg_loading.png"),
            lapisan("bingkai_loading.png"),
            *batang, 
            karakter,
            lapisan("kolom_tips.png"),
            ft.Container(content=kotak_tips, 
                         left=TIPS_KIRI * K, 
                         top=TIPS_TENGAH_Y * K - (UKURAN_TIPS * 0.6 + GARIS))
        ]
        page.update()
       
        # garis waktu: 60 langkah * 0,1 detik = 6 detik
        langkah = int(DURASI * 10)        # 60 langkah, masing-masing 0,1 detik
        for k in range(1, langkah + 1):
            p = k / langkah               # kemajuan dari 0 sampai 1
            
            terisi = round(p * JUMLAH_BATANG) #jumlah batang yang sudah hijau
            for n in range(JUMLAH_BATANG):
                batang[n].visible = n < terisi
                
            tengah = BATANG_KIRI + BATANG_LEBAR / 2 + (p * JUMLAH_BATANG - 1) * JARAK_BATANG
            karakter.left = (tengah - SPRITE / 2) * K
             
            tip = tiga_tips[(k - 1) // 20] #ganti tips tiap 2 detik
            for t in daftar_tips:
                t.value = tip
                
            page.update()
            await asyncio.sleep(0.1)
            
        await asyncio.sleep(0.5)
        game()

    # ---------- LAYAR 4: GAME ROOM 1 ----------
    def game():
        penghalang = muat_penghalang()
        nama = state["karakter"].lower()
        pos = {"x": float(KAR_MULAI[0]), "y": float(KAR_MULAI[1]), "laptop": False}
 
        def tabrakan(x, y):
            """True bila kaki karakter di (x, y) menabrak benda atau keluar dari lantai."""
            kiri, kanan = x - KAKI_LEBAR / 2, x + KAKI_LEBAR / 2
            atas, bawah = y - KAKI_TINGGI, y
            if kiri < LANTAI[0] or kanan > LANTAI[2] or atas < LANTAI[1] or bawah > LANTAI[3]:
                return True
            for l, a, r, b in penghalang:
                if kiri < r and kanan > l and atas < b and bawah > a:
                    return True
            return False
 
        # bila posisi awal menabrak sesuatu, cari tempat kosong terdekat
        if tabrakan(pos["x"], pos["y"]):
            terbaik = None
            for dy in range(-500, 501, 20):
                for dx in range(-800, 801, 20):
                    x, y = KAR_MULAI[0] + dx, KAR_MULAI[1] + dy
                    if not tabrakan(x, y):
                        jarak = dx * dx + dy * dy
                        if terbaik is None or jarak < terbaik[0]:
                            terbaik = (jarak, x, y)
            if terbaik:
                pos["x"], pos["y"] = terbaik[1], terbaik[2]
 
        karakter = ft.Image(src=f"loading_{nama}.png", width=KAR_UKURAN * K, height=KAR_UKURAN * K,
                            fit=ft.ImageFit.CONTAIN)
        bayangan = ft.Container(width=BAYANG_LEBAR * K, height=BAYANG_TINGGI * K,
                                bgcolor="#66000000", border_radius=BAYANG_LEBAR)
 
        def taruh_karakter():
            karakter.left = (pos["x"] - KAR_UKURAN / 2) * K
            karakter.top = (pos["y"] - KAR_UKURAN) * K
            bayangan.left = (pos["x"] - BAYANG_LEBAR / 2) * K
            bayangan.top = (pos["y"] - BAYANG_TINGGI / 2 - BAYANG_GESER) * K
        taruh_karakter()

        # tulisan "Tekan E" yang muncul saat dekat laptop
        petunjuk = ft.Container(
            content=ft.Text("Tekan E untuk membuka laptop", font_family=FONT, size=10, color="white"),
            bgcolor="#CC000000", border=ft.border.all(2, "white"), border_radius=8,
            padding=8, left=W / 2 - 170, top=16, width=340, alignment=ft.alignment.center,
            visible=False)

        # tulisan petunjuk setelah pintu terbuka
        petunjuk_pintu = ft.Container(
            content=ft.Text("Pintu terbuka! Masuk ke pintu untuk keluar", font_family=FONT, size=10, color="white"),
            bgcolor="#CC000000", border=ft.border.all(2, "white"), border_radius=8,
            padding=8, left=W / 2 - 180, top=60, width=460, alignment=ft.alignment.center,
            visible=False)

        # ---------- HUD NYAWA (3 hati di pojok kiri atas) ----------
        hud_hati = []
        for n in range(NYAWA_MAKS):
            hud_hati.append(ft.Image(
                src=FILE_HATI_MERAH if n < state["nyawa"] else FILE_HATI_PUTIH,
                left=(HATI_HUD_KIRI + n * (HATI_HUD + HATI_HUD_JARAK)) * K, top=HATI_HUD_ATAS * K,
                width=HATI_HUD * K, height=HATI_HUD * K, fit=ft.ImageFit.CONTAIN))

        def segarkan_hud():
            for n, h in enumerate(hud_hati):
                h.src = FILE_HATI_MERAH if n < state["nyawa"] else FILE_HATI_PUTIH

        # ---------- PINTU ----------
        pintu = lapisan(f"{RUANG}/pintu_tertutup_room1.png")
        pintu_info = {"terbuka": False}

        def buka_pintu():
            pintu_info["terbuka"] = True
            pintu.src = f"{RUANG}/{FILE_PINTU_TERBUKA}"
            petunjuk_pintu.visible = True

        def masuk_pintu():
            """True bila kaki karakter sudah berada di area pintu."""
            l, a, r, b = AREA_PINTU
            return l <= pos["x"] <= r and a <= pos["y"] <= b
        
        # ---------- LAPTOP: DESKTOP -> JIMAIL -> EMAIL -> HASIL ----------
        mode = {"layar": None}
        hasil_email = {}                       # nomor email -> True bila jawaban pemain benar
        jawaban_email = {}                     # nomor email -> jawaban pemain (True = dijawab PHISHING)
        layar_laptop = ft.Stack(width=W, height=H, visible=False)
 
        def tx(isi, ukuran=8, warna=J_TEKS, **kw):
            return ft.Text(isi, size=ukuran, color=warna, font_family=FONT, **kw)
 
        def pasang(daftar):
            layar_laptop.controls = daftar
            page.update()
 
        # jam real-time di taskbar (menutupi jam bawaan di gambar desktop)
        kotak_jam, daftar_jam = teks_garis(jam_sekarang(), 14, 8 * 14 + 2 * GARIS + 4)
        pil_jam = ft.Container(content=kotak_jam, left=JAM[0] * K, top=JAM[1] * K,
                               width=JAM[2] * K, height=JAM[3] * K, bgcolor="#6FD35B",
                               border=ft.border.all(2, "black"), border_radius=24,
                               alignment=ft.alignment.center)
 
        # ---------------- DESKTOP ----------------
        async def klik_ikon(e):
            if skenario == 1:
                tampil_inbox()
            else:
                await tampil_wasap()
         
        def tampil_desktop():
            mode["layar"] = "desktop"
            for tt in daftar_jam:
                tt.value = jam_sekarang()
            pasang([
                lapisan(FILE_DESKTOP if skenario == 1 else FILE_DESKTOP_WA),
                area_klik(*ICON_JIMAIL, klik_ikon),            # ikon Jimail (skenario 1) atau Wasap (2 dan 3)
                area_klik(*KROM_AREA, buka_krom),              # ikon Krom: aktif hanya di skenario 3
                pil_jam,
                ft.Container(content=tx("Esc = tutup laptop", 8, "white"), right=10, top=8,
                            bgcolor="#88000000", padding=6),
            ])
 
        def tampil_inbox():
            mode["layar"] = "inbox"
            item = [
                ft.Container(width=W, height=H, bgcolor=J_BG),
                ft.Container(width=W - 160, height=H - 60, left=150, top=50, bgcolor=J_PANEL,
                             border=ft.border.all(2, J_GARIS), border_radius=10),
                tx("=", 14, J_TEKS, left=12, top=12),
                tx("Jimail", 11, J_TEKS, left=44, top=14),
                ft.Container(content=tx("Telusuri jimail", 8, J_ABU), left=150, top=8, width=560, height=30,
                             bgcolor=J_PANEL, border=ft.border.all(2, J_GARIS), border_radius=14,
                             padding=ft.padding.only(left=14, top=9)),
                ft.Container(content=tx("X", 10, "white"), right=12, top=8, padding=8, bgcolor=J_AKTIF,
                             border_radius=6, on_click=lambda e: tampil_desktop()),
                ft.Container(content=tx("Tulis", 8, J_TEKS), left=8, top=52, width=120, height=36,
                             border=ft.border.all(2, J_GARIS), border_radius=10,
                             alignment=ft.alignment.center),
            ]
            menu = ["Kotak Masuk", "Berbintang", "Ditunda", "Terkirim", "Draf", "Pembelian", "Selengkapnya"]
            for n, nama_menu in enumerate(menu):
                item.append(ft.Container(content=tx(nama_menu, 7, J_TEKS), left=0, top=100 + n * 26,
                                         width=140, height=24, border_radius=6,
                                         bgcolor=J_AKTIF if n == 0 else None,
                                         padding=ft.padding.only(left=14, top=8)))
            for n, tab in enumerate(["Utama", "Promosi", "Sosial", "Info Terbaru"]):
                item.append(tx(tab, 8, "#7FA0FF" if n == 0 else J_ABU, left=170 + n * 150, top=76))
            item.append(ft.Container(left=160, top=96, width=100, height=3, bgcolor="#7FA0FF"))
            item.append(ft.Container(left=152, top=102, width=W - 164, height=2, bgcolor=J_GARIS))
            for i, em in enumerate(EMAIL):
                # benar/salah baru dibuka di halaman poin, jadi di sini hanya ditandai "sudah dijawab"
                penanda = ("DIJAWAB", J_ABU) if i in hasil_email else ("", J_ABU)
                baris = ft.Row([
                    ft.Container(width=12, height=12, border=ft.border.all(2, J_ABU)),
                    tx("*", 10, J_ABU),
                    ft.Container(tx(em["nama"], 8, J_TEKS, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS), width=180),
                    ft.Container(tx(em["subjek"], 8, J_ABU, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS), width=400),
                    tx(em["waktu"], 8, J_ABU),
                    tx(penanda[0], 7, penanda[1]),
                ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER)
                item.append(ft.Container(content=baris, left=152, top=108 + i * 40, width=W - 164, height=38,
                                         padding=ft.padding.only(left=14),
                                         border=ft.border.only(bottom=ft.BorderSide(2, J_GARIS)),
                                         on_click=lambda e, n=i: tampil_email(n)))
            item.append(tx("2% dari 15 GB digunakan", 6, J_ABU, left=14, bottom=12))
            pasang(item)
 
        def tampil_email(i):
            if i in hasil_email:               # email yang sudah dijawab tidak bisa dijawab ulang
                return
            mode["layar"] = "email"
            em = EMAIL[i]
            isi = em["isi"].replace("[Nama Pemain]", state["karakter"])
 
            def tombol(label, warna, jawab_phishing):
                async def klik(e):
                    await jawab_email(i, jawab_phishing)
                return ft.Container(content=tx(label, 9, "white"), bgcolor=warna,
                                    border=ft.border.all(2, "white"), border_radius=6,
                                    padding=ft.padding.symmetric(horizontal=18, vertical=12),
                                    on_click=klik)
 
            kolom = [ft.Container(content=tx(isi, 9, J_TEKS), width=W - 220)]
            if em["tautan"]:
                kolom.append(tx(em["tautan"], 9, "#7FA0FF"))
                kolom.append(tx("Tautan menuju: " + em["tujuan"], 7, J_ABU))
            kolom.append(ft.Container(height=6))
            kolom.append(ft.Row([tombol("PHISHING", "#B3312F", True),
                                 tombol("SAFE", "#2E8B57", False)], spacing=20))
            pasang([
                ft.Container(width=W, height=H, bgcolor=J_BG),
                ft.Container(width=W - 160, height=H - 60, left=150, top=50, bgcolor=J_PANEL,
                             border=ft.border.all(2, J_GARIS), border_radius=10),
                ft.Container(content=tx("<-", 12, J_TEKS), left=162, top=60, padding=8,
                             on_click=lambda e: tampil_inbox()),
                tx(em["subjek"], 10, J_TEKS, left=176, top=104),
                tx("[ Kotak Masuk ]", 6, J_ABU, left=176, top=124),
                ft.Container(content=tx(em["nama"][0], 12, "white"), left=176, top=146, width=36, height=36,
                             border_radius=18, bgcolor="#7E57C2", alignment=ft.alignment.center),
                tx(em["nama"], 9, J_TEKS, left=224, top=148),
                tx("<" + em["alamat"] + ">", 7, J_ABU, left=224, top=164),
                tx("kepada saya", 7, J_ABU, left=224, top=178),
                tx(em["waktu"] + " (hari ini)", 7, J_ABU, right=30, top=150),
                ft.Column(kolom, left=176, top=208, width=W - 220, spacing=14),
            ])

        async def jawab_email(i, jawab_phishing):
            """Mencatat jawaban satu email. Setelah keempat email dijawab, tampilkan halaman poin."""
            if i in hasil_email:
                return
            em = EMAIL[i]
            hasil_email[i] = (jawab_phishing == em["phishing"])
            jawaban_email[i] = jawab_phishing
            if len(hasil_email) < len(EMAIL):
                tampil_inbox()
                return
            rincian = []
            for n, e_ in enumerate(EMAIL):
                rincian.append({
                    "benar": hasil_email[n],
                    "judul": e_["subjek"],
                    "kamu": "PHISHING" if jawaban_email[n] else "SAFE",
                    "kunci": "PHISHING" if e_["phishing"] else "SAFE",
                    "alasan": e_["alasan"],
                })
            await tampil_poin(rincian)

        # ---------- SKENARIO ACAK: 1 = Jimail, 2 = Wasap kurir, 3 = Wasap Ibu + Krom ----------
        skenario = SKENARIO_PAKSA or random.choice([1, 2, 3])
        skenario_terpakai = [skenario]                     # skenario yang sudah muncul di ruangan ini
        hasil_room = {"selesai": False, "benar": None}     # selesai = halaman poin sudah tampil; benar = lulus ruangan
        chat = {"mulai": False, "item": None, "kolom": None, "status": None, "panel": None}
        krom = {"aktif": False, "pilih": {}}
 
        def jam_chat():
            return datetime.now().strftime("%H.%M")
 
        def tbl(label, warna, klik, ukuran=9):
            return ft.Container(content=tx(label, ukuran, "white"), bgcolor=warna,
                                border=ft.border.all(2, "white"), border_radius=6,
                                padding=ft.padding.symmetric(horizontal=18, vertical=12), on_click=klik)

        # ---------------- HALAMAN POIN + MANAJEMEN NYAWA ----------------
        def tutup_laptop():
            pos["laptop"] = False
            layar_laptop.visible = False
            mode["layar"] = None
            segarkan_hud()
            # lulus ruangan + laptop ditutup -> pintu berubah dari Tertutup menjadi Terbuka
            if hasil_room["selesai"] and hasil_room["benar"] and not pintu_info["terbuka"]:
                buka_pintu()
            segarkan()

        def ulangi_skenario():
            """Try Again: ulang di ruangan ini saja dengan skenario BERBEDA. Nyawa TIDAK direset."""
            nonlocal skenario
            if SKENARIO_PAKSA is None:                     # bila skenario dipaksa (mode tes), tetap sama
                sisa = [s for s in (1, 2, 3) if s not in skenario_terpakai]
                if not sisa:                               # semua sudah pernah muncul: ulang tapi bukan yang barusan
                    skenario_terpakai.clear()
                    sisa = [s for s in (1, 2, 3) if s != skenario]
                skenario = random.choice(sisa)
                skenario_terpakai.append(skenario)
            hasil_email.clear()
            jawaban_email.clear()
            chat.update(mulai=False, item=None, kolom=None, status=None, panel=None)
            krom.update(aktif=False, pilih={})
            hasil_room.update(selesai=False, benar=None)
            tampil_desktop()

        async def layar_kalah():
            """Layar sementara YOU LOSE (3 hati sudah putih)."""
            page.on_keyboard_event = None
            async def ulang(e):
                await loading()                # game diulang dari awal: nyawa penuh, poin nol
            stage.controls = [
                ft.Container(width=W, height=H, bgcolor="black"),
                ft.Container(content=ft.Text("YOU LOSE", font_family=FONT, size=30, color="#FF4B4B"),
                             width=W, height=H, alignment=ft.alignment.center),
                ft.Container(content=tbl("Try Again", "#B3312F", ulang, 12),
                             top=H / 2 + 60, left=0, width=W, alignment=ft.alignment.center),
            ]
            page.update()

        async def fade(kotak, dari, ke, detik, langkah=24):
            """Mengubah opacity kotak dari 'dari' ke 'ke' secara bertahap."""
            for n in range(1, langkah + 1):
                kotak.opacity = dari + (ke - dari) * n / langkah
                kotak.update()
                await asyncio.sleep(detik / langkah)

        async def escape_room():
            """Fade ke putih -> layar putih 'YOU ESCAPE THE ROOM' -> fade dari putih ke ruangan berikutnya."""
            page.on_keyboard_event = None
            def ke_menu(e):
                home()
            # 1. fade ruangan menjadi putih
            tirai = ft.Container(width=W, height=H, bgcolor="white", opacity=0)
            stage.controls.append(tirai)
            page.update()
            await fade(tirai, 0, 1, FADE_KE_PUTIH)
            # 2. layar putih polos + teks
            stage.controls = [
                ft.Container(width=W, height=H, bgcolor="white"),
                ft.Container(content=ft.Text("YOU ESCAPE THE ROOM", font_family=FONT, size=26, color="black"),
                             width=W, height=H, alignment=ft.alignment.center),
            ]
            page.update()
            await asyncio.sleep(TAHAN_PUTIH)
            # 3. ruangan berikutnya (sementara: layar hitam + tombol Back to Menu), muncul dengan fade dari putih
            tirai = ft.Container(width=W, height=H, bgcolor="white", opacity=1)
            stage.controls = [
                ft.Container(width=W, height=H, bgcolor="black"),
                ft.Container(content=tbl("Back to Menu", "#333333", ke_menu, 12),
                             top=H / 2 - 20, left=0, width=W, alignment=ft.alignment.center),
                tirai,
            ]
            page.update()
            await fade(tirai, 1, 0, FADE_DARI_PUTIH)
            stage.controls.remove(tirai)                   # lepas tirai supaya tombol bisa diklik
            page.update()

        async def tampil_poin(rincian):
            """Halaman poin di akhir skenario. rincian = daftar dict:
            {"benar": bool, "judul": str, "kamu": str, "kunci": str, "alasan": [str, ...]}"""
            if mode["layar"] == "poin":        # cegah klik ganda mengurangi nyawa dua kali
                return
            mode["layar"] = "poin"
            total = len(rincian)
            benar_n = sum(1 for r in rincian if r["benar"])
            lulus = benar_n >= min(MINIMAL_BENAR, total)
            poin = POIN_BENAR if lulus else POIN_SALAH
            nyawa_lama = state["nyawa"]
            if not lulus:
                state["nyawa"] = max(0, nyawa_lama - 1)
            habis = state["nyawa"] <= 0
            state["skor"][RUANG] = poin        # satu skor per ruangan (percobaan terakhir yang dihitung)
            total_poin = sum(state["skor"].values())
            hasil_room.update(selesai=True, benar=lulus)

            # hati: semua kondisi SEBELUM pengurangan dulu, animasi menyusul bila gagal
            hati = [ft.Image(src=FILE_HATI_MERAH if n < nyawa_lama else FILE_HATI_PUTIH,
                             width=56, height=54, fit=ft.ImageFit.CONTAIN) for n in range(NYAWA_MAKS)]

            # penjelasan tiap pertanyaan
            daftar = []
            for n, r in enumerate(rincian, 1):
                warna = P_ALASAN_BENAR if r["benar"] else P_ALASAN_SALAH
                daftar.append(ft.Container(content=tx(f"{n}. {r['judul']}", 8, P_ALASAN_JUDUL), width=810))
                if r["benar"]:
                    status = f"Jawabanmu: {r['kamu']} - BENAR"
                else:
                    status = f"Jawabanmu: {r['kamu']} - SALAH. Jawaban benar: {r['kunci']}"
                daftar.append(ft.Container(content=tx(status, 7, warna), width=810))
                for a in r["alasan"]:
                    daftar.append(ft.Container(content=tx("- " + a, 7, P_ALASAN_ISI), width=810))
                daftar.append(ft.Container(height=6))

            # tombol navigasi (muncul setelah animasi selesai)
            async def klik_tutup(e):
                tutup_laptop()
            async def klik_ulang(e):
                ulangi_skenario()
            async def klik_lanjut(e):
                await layar_kalah()
            if lulus:
                tombol_nav = tbl("Tutup Laptop", P_BENAR, klik_tutup, 10)
            elif habis:
                tombol_nav = tbl("Next", "#5F6368", klik_lanjut, 10)       # nyawa habis -> menuju YOU LOSE
            else:
                tombol_nav = tbl("Try Again", "#1A73E8", klik_ulang, 10)
            area_tombol = ft.Container(content=tombol_nav, visible=False)

            if lulus:
                teks_kondisi, warna_kondisi = "Yay, your answer is correct<3", P_BENAR
                teks_poin = f"Benar {benar_n}/{total}  |  Poin: +{POIN_BENAR}  |  Total: {total_poin}"
            else:
                teks_kondisi, warna_kondisi = "Sorry, your answer is incorrect:(", P_SALAH
                teks_poin = (f"Benar {benar_n}/{total}  |  Poin: {POIN_BENAR} - {POIN_BENAR - POIN_SALAH} = "
                             f"{POIN_SALAH}  |  Total: {total_poin}")

            isi = ft.Column([
                tx(teks_kondisi, 15, warna_kondisi),
                tx(teks_poin, 8, P_ABU),
                ft.Row(hati, alignment=ft.MainAxisAlignment.CENTER, spacing=14),
                ft.Container(content=ft.Column(daftar, spacing=3, scroll=ft.ScrollMode.AUTO),
                             width=840, height=240, bgcolor=P_ALASAN_BG, border=ft.border.all(1, P_ALASAN_GARIS),
                             border_radius=8, padding=ft.padding.symmetric(horizontal=12, vertical=8)),
                area_tombol,
            ], width=852, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10)

            pasang([
                ft.Container(width=W, height=H, bgcolor=P_BG),
                ft.Container(content=isi, left=40, top=20, width=880, height=500, bgcolor=P_KARTU,
                             border=ft.border.all(1, P_GARIS), border_radius=16, padding=14),
            ])

            if not lulus:
                # hati yang hilang (yang paling kanan yang masih aktif) berkedip merah-mati 2 kali,
                # lalu berubah permanen menjadi putih
                idx = nyawa_lama - 1
                await asyncio.sleep(0.8)
                for _ in range(2):
                    hati[idx].src = FILE_HATI_PUTIH
                    page.update()
                    await asyncio.sleep(KEDIP_JEDA)
                    hati[idx].src = FILE_HATI_MERAH
                    page.update()
                    await asyncio.sleep(KEDIP_JEDA)
                hati[idx].src = FILE_HATI_PUTIH
                page.update()
                await asyncio.sleep(0.4)
            area_tombol.visible = True
            page.update()
 
        # ---------------- WASAP (tampilan chat bergaya WhatsApp, versi pixel) ----------------
        def gelembung(teks, masuk):
            lebar = min(500, max(90, max(len(b) for b in teks.split("\n")) * 8 + 24))
            isi = ft.Column([tx(teks, 8, "#111B21"), tx(jam_chat(), 6, "#667781")], spacing=4)
            bub = ft.Container(content=isi, width=lebar, padding=8, border_radius=8,
                               bgcolor="#FFFFFF" if masuk else "#DCF8C6",
                               border=ft.border.all(2, "#111B21"))
            return ft.Row([bub], alignment=ft.MainAxisAlignment.START if masuk else ft.MainAxisAlignment.END)
 
        def panel_kosong():
            return ft.Container(content=tx("Ketik pesan", 8, "#8696A0"), width=W - 40, bgcolor="#FFFFFF",
                                border=ft.border.all(2, "#111B21"), border_radius=16,
                                padding=ft.padding.symmetric(horizontal=14, vertical=10))
 
        async def terima(teks):
            chat["status"].value = "mengetik..."
            page.update()
            await asyncio.sleep(min(2.2, 0.8 + len(teks) * 0.004))
            chat["status"].value = "online"
            chat["kolom"].controls.append(gelembung(teks, True))
            page.update()
 
        def kirim(teks):
            chat["kolom"].controls.append(gelembung(teks, False))
            page.update()
 
        def catatan(teks):
            chat["kolom"].controls.append(ft.Row([ft.Container(
                content=tx("CLUE: " + teks, 7, "#5A4A00"), width=580, padding=8, bgcolor="#FFF3BF",
                border=ft.border.all(2, "#B59B00"), border_radius=6)], alignment=ft.MainAxisAlignment.CENTER))
            page.update()
 
        async def tanya(pilihan, huruf="", besar=False):
            """Menampilkan pilihan di panel bawah dan menunggu pemain memilih. Mengembalikan nomor pilihan."""
            fut = asyncio.get_running_loop().create_future()
 
            def tombol_pilih(n, label):
                async def klik(e):
                    if not fut.done():
                        fut.set_result(n)
                if besar:
                    return ft.Container(content=tx(label, 9, "white"), width=(W - 50) / 2, height=100,
                                        bgcolor="#2B5BA8", border=ft.border.all(2, "#111B21"), border_radius=8,
                                        padding=10, alignment=ft.alignment.center, on_click=klik)
                return ft.Container(content=tx(huruf[n] + ". " + label, 7, "#111B21"), width=W - 36,
                                    bgcolor="#FFFFFF", border=ft.border.all(2, "#111B21"), border_radius=6,
                                    padding=8, on_click=klik)
 
            tombol = [tombol_pilih(n, p) for n, p in enumerate(pilihan)]
            chat["panel"].content = ft.Row(tombol, spacing=10) if besar else ft.Column(tombol, spacing=6)
            page.update()
            n = await fut
            chat["panel"].content = panel_kosong()
            page.update()
            return n
 
        async def alur_kurir():
            await terima(KURIR["awal"])
            p = await tanya(KURIR["babak1"], "ABC")
            if p < 2:
                kirim(KURIR["babak1"][p])
                await terima(KURIR["balas1"][p])
                catatan(KURIR["clue1"][p])
                q = await tanya(KURIR["babak2"], "DE")
                kirim(KURIR["babak2"][q])
                await terima(KURIR["balas2"])
            n = await tanya(KURIR["keputusan"], besar=True)
            benar = (n == KURIR["benar_idx"])
            # pada skenario ini hanya keputusan akhir yang dinilai (1 pertanyaan)
            alasan = [KURIR["alasan"][n]]
            if not benar:
                alasan.append(KURIR["alasan"][KURIR["benar_idx"]])
            rincian = [{
                "benar": benar,
                "judul": "Keputusan akhir pada chat kurir",
                "kamu": KURIR["keputusan"][n],
                "kunci": KURIR["keputusan"][KURIR["benar_idx"]],
                "alasan": alasan,
            }]
            await asyncio.sleep(0.5)
            await tampil_poin(rincian)
 
        async def alur_ibu():
            for kalimat in IBU["awal"]:
                await terima(kalimat)
            p = await tanya(IBU["pilihan"], "AB")
            kirim(IBU["pilihan"][p])
            for kalimat in IBU["balas"]:
                await terima(kalimat)
            krom["aktif"] = True
            catatan("Riwayat link Ibu akan terbuka di Krom sebentar lagi..." if OTOMATIS_KE_KROM else IBU["petunjuk"])
            if OTOMATIS_KE_KROM:
                await asyncio.sleep(JEDA_KE_KROM)
                if mode["layar"] == "wasap":      
                    tampil_krom()
 
        async def tampil_wasap():
            mode["layar"] = "wasap"
            if chat["mulai"]:                       # sudah pernah dibuka: tampilkan obrolan yang berjalan
                pasang(chat["item"])
                return
            chat["mulai"] = True
            nama_kontak = KURIR["nomor"] if skenario == 2 else IBU["nama"]
            chat["status"] = tx("online", 6, "#C8E6C9", left=94, top=32)
            chat["kolom"] = ft.Column(spacing=8, scroll=ft.ScrollMode.AUTO, auto_scroll=True,
                                      left=14, top=62, width=W - 28, height=H - 62 - 170)
            chat["panel"] = ft.Container(content=panel_kosong(), left=0, top=H - 170, width=W, height=170,
                                         bgcolor="#F0F2F5", padding=ft.padding.symmetric(horizontal=18, vertical=10),
                                         border=ft.border.only(top=ft.BorderSide(2, "#111B21")))
            chat["item"] = [
                ft.Container(width=W, height=H, bgcolor="#ECE5DD"),
                chat["kolom"],
                ft.Container(width=W, height=54, bgcolor="#075E54", border=ft.border.only(bottom=ft.BorderSide(2, "#111B21"))),
                ft.Container(content=tx("<-", 12, "white"), left=8, top=12, padding=6,
                             on_click=lambda e: tampil_desktop()),
                ft.Container(content=tx(nama_kontak[0], 10, "white"), left=48, top=9, width=36, height=36,
                             border_radius=18, bgcolor="#9AA5B1", alignment=ft.alignment.center),
                tx(nama_kontak, 9, "white", left=94, top=12),
                chat["status"],
                chat["panel"],
            ]
            pasang(chat["item"])
            if skenario == 2:
                await alur_kurir()
            else:
                await alur_ibu()
 
        # ---------------- KROM (riwayat peramban bergaya Chrome, versi pixel) ----------------
        def tandai(n, nilai):
            krom["pilih"][n] = nilai
            tampil_krom()
 
        def tampil_krom():
            mode["layar"] = "krom"
            pilih = krom["pilih"]
            item = [
                ft.Container(width=W, height=H, bgcolor="#FFFFFF"),
                ft.Container(width=W, height=36, bgcolor="#DEE1E6"),
                ft.Container(content=tx("Riwayat", 7, "#202124"), left=10, top=8, width=170, height=28,
                             bgcolor="#FFFFFF", padding=ft.padding.only(left=12, top=9), border_radius=6),
                ft.Container(content=tx("X", 9, "white"), right=8, top=5, padding=6, bgcolor="#C0392B",
                             border_radius=6, on_click=lambda e: tampil_desktop()),
                ft.Container(width=W, height=2, top=36, bgcolor="#9AA0A6"),
                tx("<-  ->  O", 9, "#5F6368", left=14, top=52),
                ft.Container(content=tx("krom://history", 8, "#202124"), left=130, top=44, width=560, height=28,
                             bgcolor="#F1F3F4", border_radius=14, border=ft.border.all(2, "#9AA0A6"),
                             padding=ft.padding.only(left=16, top=9)),
                ft.Container(width=W, height=2, top=80, bgcolor="#DADCE0"),
                tx("Riwayat", 14, "#202124", left=210, top=96),
                ft.Container(content=tx("Telusuri riwayat", 7, "#5F6368"), right=18, top=94, width=300, height=28,
                             bgcolor="#F1F3F4", border_radius=14, padding=ft.padding.only(left=14, top=9)),
                tx("Hari ini - " + tanggal_id(), 8, "#202124", left=210, top=140),
            ]
            for n, nama_menu in enumerate(["Riwayat", "Grup tab", "Tab perangkat lain", "Hapus data penjelajahan"]):
                item.append(ft.Container(content=tx(nama_menu, 7, "#041E49" if n == 0 else "#202124"), left=0,
                                         top=96 + n * 30, width=190, height=26, border_radius=6,
                                         bgcolor="#D3E3FD" if n == 0 else None,
                                         padding=ft.padding.only(left=14, top=9)))
            for i, h in enumerate(URL_KROM):
                def tombol_tandai(label, nilai):
                    aktif = (pilih.get(i) == nilai)
                    warna = ("#1E8E3E" if nilai == "resmi" else "#C5221F") if aktif else "#E8EAED"
                    return ft.Container(content=tx(label, 7, "white" if aktif else "#202124"), bgcolor=warna,
                                        border=ft.border.all(2, "#202124"), border_radius=6,
                                        padding=ft.padding.symmetric(horizontal=8, vertical=7),
                                        on_click=lambda e, n=i, v=nilai: tandai(n, v))
                baris = ft.Row([
                    ft.Container(width=12, height=12, border=ft.border.all(2, "#5F6368")),
                    tx(h["waktu"], 7, "#5F6368"),
                    ft.Container(content=tx("f", 8, "white"), width=18, height=18, bgcolor="#1877F2",
                                 alignment=ft.alignment.center, border_radius=3),
                    ft.Container(ft.Column([tx(h["judul"], 8, "#202124", max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                                            tx(h["url"], 7, "#5F6368", max_lines=1, overflow=ft.TextOverflow.ELLIPSIS)],
                                           spacing=5), width=340),
                    tombol_tandai("RESMI", "resmi"), tombol_tandai("PALSU", "palsu"),
                ], spacing=14, vertical_alignment=ft.CrossAxisAlignment.CENTER)
                item.append(ft.Container(content=baris, left=200, top=164 + i * 50, width=W - 216, height=46,
                                         padding=ft.padding.only(left=10),
                                         border=ft.border.only(bottom=ft.BorderSide(2, "#DADCE0"))))
            if len(pilih) == len(URL_KROM):
                async def klik_periksa(e):
                    await periksa_krom()
                periksa = tbl("PERIKSA JAWABAN", "#1A73E8", klik_periksa)
                periksa.left, periksa.top = 210, H - 76
                item.append(periksa)
            else:
                item.append(tx("Tandai tiap halaman: RESMI atau PALSU, lalu tekan PERIKSA.", 7, "#5F6368",
                               left=210, top=H - 70))
            pasang(item)
 
        async def periksa_krom():
            rincian = []
            for i, h in enumerate(URL_KROM):
                jawab_resmi = (krom["pilih"][i] == "resmi")
                rincian.append({
                    "benar": jawab_resmi == h["resmi"],
                    "judul": f"{h['judul']} ({h['url']})",
                    "kamu": "RESMI" if jawab_resmi else "PALSU",
                    "kunci": "RESMI" if h["resmi"] else "PALSU",
                    "alasan": [h["alasan"]],
                })
            await tampil_poin(rincian)
 
        def buka_krom(e=None):
            if skenario == 3 and krom["aktif"] and mode["layar"] != "krom":
                tampil_krom()
 
        async def jam_loop():
            """Memperbarui jam di desktop laptop setiap detik."""
            while karakter in stage.controls:
                if layar_laptop.visible and mode["layar"] == "desktop":
                    try:
                        for tt in daftar_jam:
                            tt.value = jam_sekarang()
                        kotak_jam.update()
                    except Exception:
                        pass
                await asyncio.sleep(1)
 
        # kotak penolong untuk melihat area tabrakan (DEBUG_KOTAK)
        debug = []
        if DEBUG_KOTAK:
            def kotak(l, a, r, b, warna, isi=None):
                return ft.Container(left=l * K, top=a * K, width=(r - l) * K, height=(b - a) * K,
                                    border=ft.border.all(2, warna), bgcolor=isi)
            debug.append(kotak(*LANTAI, "yellow"))
            debug.append(kotak(*AREA_LAPTOP, "cyan"))
            debug.append(kotak(*AREA_PINTU, "magenta"))
            for l, a, r, b in penghalang:
                debug.append(kotak(l, a, r, b, "red", "#55FF0000"))
 
        def dekat_laptop():
            if hasil_room["selesai"] and hasil_room["benar"]:     # tugas laptop sudah lulus: tidak perlu dibuka lagi
                return False
            l, a, r, b = AREA_LAPTOP
            return (l - JARAK_LAPTOP <= pos["x"] <= r + JARAK_LAPTOP
                    and a - JARAK_LAPTOP <= pos["y"] <= b + JARAK_LAPTOP)
 
        def segarkan():
            petunjuk.visible = (not pos["laptop"]) and dekat_laptop()
            page.update()
 
        def buka_laptop():
            if dekat_laptop() and not pos["laptop"]:
                pos["laptop"] = True
                petunjuk.visible = False
                layar_laptop.visible = True
                tampil_desktop()          # menampilkan desktop laptop (lalu Jimail dan email)
 
        ARAH = {"arrow left": (-1, 0), "arrow right": (1, 0), "arrow up": (0, -1), "arrow down": (0, 1),
                "a": (-1, 0), "d": (1, 0), "w": (0, -1), "s": (0, 1)}
 
        tahan = {"tombol": None, "terakhir": 0.0, "ulang": False}

        def gerak(dx, dy, jarak):
            """Geser karakter sejauh 'jarak', per 4 piksel supaya rapat ke benda."""
            sisa = jarak
            while sisa > 0:
                s = min(4, sisa)
                if tabrakan(pos["x"] + dx * s, pos["y"] + dy * s):
                    break
                pos["x"] += dx * s
                pos["y"] += dy * s
                sisa -= s

        def perbarui_petunjuk():
            tampil = (not pos["laptop"]) and dekat_laptop()
            if petunjuk.visible != tampil:
                petunjuk.visible = tampil
                petunjuk.update()

        async def loop_gerak():
            """Satu loop yang berjalan terus: menggerakkan karakter selama tombol arah masih aktif."""
            waktu_lalu = time.monotonic()
            while karakter in stage.controls:
                await asyncio.sleep(1 / 60)
                sekarang = time.monotonic()
                dt = min(sekarang - waktu_lalu, 0.05)     # dibatasi agar tidak melompat saat lag
                waktu_lalu = sekarang
                k = tahan["tombol"]
                if k is None or pos["laptop"]:
                    continue
                batas = LEPAS_DETIK if tahan["ulang"] else AWAL_DETIK
                if sekarang - tahan["terakhir"] > batas:  # tombol dianggap dilepas
                    tahan["tombol"] = None
                    perbarui_petunjuk()
                    continue
                dx, dy = ARAH[k]
                gerak(dx, dy, KECEPATAN * dt)
                taruh_karakter()
                bayangan.update()
                karakter.update()
                perbarui_petunjuk()
                # karakter masuk ke pintu yang sudah terbuka -> animasi escape
                if pintu_info["terbuka"] and masuk_pintu():
                    await escape_room()
                    return

        async def on_key(e: ft.KeyboardEvent):
            k = e.key.lower()
            if pos["laptop"]:                             # saat laptop terbuka, karakter diam
                if k == "escape" and mode["layar"] != "poin":   # di halaman poin laptop hanya bisa ditutup lewat tombol
                    tutup_laptop()
                return
            if k in ARAH:
                t = time.monotonic()
                if tahan["tombol"] == k and t - tahan["terakhir"] < JEDA_TAHAN:
                    tahan["terakhir"] = t                 # sinyal ulang: tombol sedang ditahan
                    tahan["ulang"] = True
                else:                                     # tekan baru (atau ganti arah)
                    tahan.update(tombol=k, terakhir=t, ulang=False)
            elif k in TOMBOL_BUKA:
                buka_laptop()
        page.on_keyboard_event = on_key
 
        teks_monolog = ft.Text(value="", font_family=FONT, size=11, color="white")
        kotak_monolog = ft.Container(
            content=teks_monolog, bgcolor="#CC000000", border=ft.border.all(2, "white"),
            border_radius=10, padding=15, width=W - 40, height=120, bottom=20, left=20)
 
        stage.controls = [
            lapisan(f"{RUANG}/bg_polos_room1.png"),
 
            # dinding belakang
            lapisan(f"{RUANG}/papan_tulis_room1.png"),
            lapisan(f"{RUANG}/mading_room1.png"),
            pintu,                                      # pintu: tertutup, berubah terbuka setelah tugas selesai
 
            # sisi kiri
            lapisan(f"{RUANG}/kardus_room1.png"),
            lapisan(f"{RUANG}/rak_buku_room1.png"),
 
            # tengah
            lapisan(f"{RUANG}/pot_bunga_room1.png"),
            lapisan(f"{RUANG}/meja_depan_room1.png"),
            lapisan(f"{RUANG}/laptop_room1.png"),
 
            bayangan,                                   # bayangan di bawah karakter
            karakter,                                   # karakter di atas benda tengah, di bawah meja terdepan
            lapisan(f"{RUANG}/3meja_room1.png"),        # paling depan
 
            *debug,
            *hud_hati,                                  # HUD nyawa di pojok kiri atas
            area_klik(1250, 365, 200, 190, lambda e: buka_laptop()),   # klik laptop (hanya bila dekat)
            petunjuk,
            petunjuk_pintu,
            kotak_monolog,
            layar_laptop,
        ]
        page.update()
        asyncio.create_task(loop_gerak())
        asyncio.create_task(jam_loop())
 
        async def animasi_monolog():
            cerita_utuh = ("Sekarang kamu berada di sebuah gedung, kamu terjebak di ruangan ini, "
                           "kamu harus menyelesaikan masalah yang ada di komputer ruangan ini agar bisa "
                           "lanjut ke ruangan selanjutnya, lakukan hingga ruangan terakhir agar bisa "
                           "keluar dari gedung ini. Good luck!")
            teks_berjalan = ""
            for huruf in cerita_utuh:
                teks_berjalan += huruf
                teks_monolog.value = teks_berjalan
                page.update()
                await asyncio.sleep(0.04)
            await asyncio.sleep(5.0)
            kotak_monolog.visible = False
            page.update()
 
        asyncio.create_task(animasi_monolog())

    home()

ft.app(target=main, view=ft.AppView.WEB_BROWSER, assets_dir="assets")
