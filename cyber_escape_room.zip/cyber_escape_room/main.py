import asyncio
import time
import random
import flet as ft
import os
from datetime import datetime

W, H = 960, 540 # ukuran layar game (pixel)
K = 0.5         # skala: koordinat desain 1920x1080 menjadi layar 960x540
# Ubah ke True setelah file font ditaruh di assets/fonts
PAKAI_FONT = True

TIPS = [
    "Jangan pernah membagikan kode OTP kepada siapa pun.", 
    "Gunakan password panjang dan unik untuk setiap akun.", 
    "Periksa alamat pengirim sebelum mengeklik tautan di email atau pesan.", 
    "Bandingkan hash file unduhan dengan hash resmi untuk memastikan file tidak berubah.", 
    "Jika perangkatmu terkena serangan, segera putuskan dari jaringan dan laporkan.", 
    "Cek izin aplikasi. Tolak izin yang tidak sesuai dengan fungsinya.", 
    "Aktifkan verifikasi dua langkah (MFA) agar akunmu lebih aman.", 
    "Pesan yang membuatmu panik dan menyuruh bertindak cepat sering kali phishing.", 
    "Batasi permission file penting agar tidak sembarang orang bisa mengubahnya.",
    "Catat kronologi insiden. Itu bahan evaluasi agar kejadian serupa tidak terulang.",
 ]

DURASI = 6.0                           # lama loading (detik)
JUMLAH_BATANG = 16                     # jumlah batang hijau di dalam bingkai
BATANG_KIRI, BATANG_ATAS = 512,543        
BATANG_LEBAR, BATANG_TINGGI = 48, 64
JARAK_BATANG = 58.2                    # jarang dari satu batang ke batang berikutnya
SPRITE, SPRITE_ATAS = 110, 412         # ukuran dan tinggi karakter kecil
TIPS_KIRI, TIPS_TENGAH_Y = 200, 1032   # posisi teks tips
GARIS = 2                              # tebal garis hitam di pinggir teks tips
UKURAN_TIPS = 10                       # ukuran teks tips (10 = semua tips muat)
BASE = os.path.dirname(os.path.abspath(__file__))

# ---------- PENGATURAN ROOM 1 (koordinat desain 1920x1080) ----------
RUANG = "Room 1"                       # nama folder gambar ruangan di dalam assets
KAR_UKURAN = 360                       # ukuran gambar karakter
KAR_MULAI = (900, 830)                 # posisi awal: (x tengah badan, y kaki)
LANGKAH = 24                           # jarak satu kali menekan panah
KAKI_LEBAR, KAKI_TINGGI = 130, 40       # kotak kaki karakter (dipakai untuk tabrakan)
LANTAI = (20, 690, 1900, 920)          # batas lantai yang boleh diinjak: kiri, atas, kanan, bawah
BAGIAN_BAWAH = {                       # benda penghalang: bagian bawah benda yang menghalangi (1.0 = seluruhnya)
    "kardus_room1.png": 0.35,
    "rak_buku_room1.png": 0.12,
    "pot_bunga_room1.png": 0.22,
    "meja_depan_room1.png": 0.33,
}
AREA_LAPTOP = (1135, 450, 1495, 768)   # kotak laptop: kiri, atas, kanan, bawah
JARAK_LAPTOP = 150                     # seberapa dekat karakter harus berdiri dari laptop
TOMBOL_BUKA = ("e", "enter", " ")      # tombol membuka/menutup laptop (E, Enter, atau Spasi)
AWAL_DETIK = 0.6       # toleransi setelah tekan pertama (menunggu jeda awal key repeat Windows)
LEPAS_DETIK = 0.2      # setelah sinyal ulang datang, tanpa sinyal selama ini = dianggap dilepas
JEDA_TAHAN = 0.8       # sinyal tombol yang sama dalam jeda ini dianggap tombol masih ditahan
KECEPATAN = 420        # kecepatan jalan (piksel desain per detik)
BAYANG_LEBAR, BAYANG_TINGGI = 185, 44   # ukuran bayangan lonjong di kaki karakter
BAYANG_GESER = 12      # naik/turun bayangan (makin besar = makin ke atas)
DEBUG_KOTAK = False                    # True = tampilkan kotak merah penghalang; ubah ke False kalau sudah pas

FILE_DESKTOP = "desktop_laptop.jpeg"    # gambar desktop laptop (simpan di folder assets)
ICON_JIMAIL = (64, 36, 170, 200)        # area klik ikon Jimail: kiri, atas, lebar, tinggi (koordinat desain 1920x1080)
JAM = (1574, 966, 346, 114)              # kotak jam hijau: kiri, atas, lebar, tinggi (menutupi jam di gambar)
 
# warna tampilan Jimail
J_BG, J_PANEL, J_GARIS = "#171C4A", "#0C1236", "#4C5FC8"
J_TEKS, J_ABU, J_AKTIF = "#EAF0FF", "#9AA6E0", "#3B4A9C"
 
# 4 email: dua phishing, dua asli. Ubah teks/waktu di sini kapan saja.
EMAIL = [
    {
        "nama": "Sistem Akademik Kampus",
        "alamat": "admin-siakad@universitas-kemdikbud-id.com",
        "subjek": "[URGENT] Akun SIAKAD Anda Ditangguhkan - Segera Verifikasi!",
        "waktu": "08.15",
        "isi": ("Halo Mahasiswa,\n\nKami mendeteksi adanya aktivitas login mencurigakan pada akun Sistem "
                "Informasi Akademik (SIAKAD) Anda dari perangkat di luar kota. Untuk keamanan, akun Anda "
                "telah ditangguhkan sementara. Harap lakukan verifikasi ulang dalam waktu 24 jam agar Anda "
                "tetap bisa mengakses jadwal UTS. Klik link berikut untuk verifikasi:"),
        "tautan": "Verifikasi Akun SIAKAD Disini",
        "tujuan": "http://siakad-univ-verification.net",
        "phishing": True,
        "alasan": ["Urgensi berlebihan: akun diancam hangus dalam 24 jam menjelang UTS.",
                   "Domain salah: email resmi kampus memakai format nama-univ.ac.id, bukan .com atau .net."],
    },
    {
        "nama": "Kampus Merdeka",
        "alamat": "no-reply@kampusmerdeka.kemdikbud.go.id",
        "subjek": "Undangan Wawancara Program Magang Merdeka - Batch 2027",
        "waktu": "09.40",
        "isi": ("Yth. Pendaftar Program Magang Merdeka,\n\nBerdasarkan seleksi berkas yang telah dilakukan, "
                "Anda dinyatakan lolos ke tahap wawancara. Jadwal wawancara dan detail teknis dapat Anda "
                "lihat langsung dengan masuk ke dasbor akun resmi Kampus Merdeka Anda. Kami tidak memungut "
                "biaya apa pun dalam proses ini."),
        "tautan": "Dasbor Kampus Merdeka",
        "tujuan": "https://kemdikbud.go.id",
        "phishing": False,
        "alasan": ["Domain resmi: memakai ekstensi .go.id (pemerintah).",
                   "Tidak meminta data sensitif: pemain tidak disuruh klik link aneh, melainkan diminta "
                   "mengecek dasbor resmi secara mandiri."],
    },
    {
        "nama": "Komite Beasiswa Pendidikan",
        "alamat": "info@beasiswa-mahasiswa-indonesia.org",
        "subjek": "Pemberitahuan: Dana Bantuan UKT Semester Ganjil 2026/2027",
        "waktu": "10.05",
        "isi": ("Selamat! Anda terpilih sebagai salah satu penerima bantuan subsidi UKT sebesar Rp2.500.000 "
                "untuk semester ini. Dana akan langsung ditransfer ke rekening Anda. Untuk mencairkan dana "
                "tersebut, silakan daftarkan nomor kartu debit/kredit beserta kode CVV Anda melalui formulir "
                "digital di bawah ini:"),
        "tautan": "Formulir Pencairan Dana UKT",
        "tujuan": "https://forms.gle",
        "phishing": True,
        "alasan": ["Terlalu bagus untuk jadi nyata: mendapat beasiswa tanpa pernah mendaftar.",
                   "Meminta data finansial rahasia: nomor kartu dan kode CVV tidak boleh dibagikan kepada siapa pun."],
    },
    {
        "nama": "Perpustakaan Pusat",
        "alamat": "library@univ-kamu.ac.id",
        "subjek": "[Perpustakaan Pusat] Pengingat Pengembalian Buku Telat",
        "waktu": "11.20",
        "isi": ("Halo [Nama Pemain],\n\nSistem kami mencatat bahwa Anda belum mengembalikan buku berjudul "
                "'Pengantar Teknologi Informasi' yang jatuh tempo pada 18 November 2026. Saat ini denda "
                "keterlambatan Anda adalah sebesar Rp10.000. Harap segera mengembalikan buku ke loket "
                "perpustakaan utama pada jam kerja."),
        "tautan": None,
        "tujuan": None,
        "phishing": False,
        "alasan": ["Informasi spesifik: menyebut judul buku dan tanggal yang jelas, bukan sapaan umum.",
                   "Instruksi fisik: penyelesaian dilakukan dengan datang ke loket perpustakaan kampus."],
    },
]
 
def jam_sekarang():
    """Jam saat ini untuk taskbar laptop, misalnya 14.05 PM."""
    n = datetime.now()
    return n.strftime("%H.%M") + (" PM" if n.hour >= 12 else " AM")
 
def muat_penghalang():
    """Baca gambar benda di assets/Room 1 lalu buat kotak tabrakan dari bagian bawah tiap benda."""
    kotak = []
    try:
        from PIL import Image
    except ImportError:
        print("Pillow belum terpasang, tabrakan benda tidak aktif")
        return kotak
    for nama, bagian in BAGIAN_BAWAH.items():
        jalur = os.path.join(BASE, "assets", RUANG, nama)
        if not os.path.exists(jalur):
            print("Gambar tidak ditemukan:", jalur)
            continue
        gambar = Image.open(jalur).convert("RGBA")
        skala = 1920 / gambar.width
        bb = gambar.getchannel("A").point(lambda a: 255 if a > 20 else 0).getbbox()
        if bb is None:
            continue
        kiri, atas, kanan, bawah = [v * skala for v in bb]
        kotak.append((kiri, bawah - (bawah - atas) * bagian, kanan, bawah))
    return kotak

def main(page: ft.Page):
    page.title = "Cybersecurity Awareness Escape Room"
    page.bgcolor = "black"
    page.padding = 0
    
    FONT = None
    if PAKAI_FONT:
        page.fonts = {"Pixel": "fonts/PressStart2P-Regular.ttf"}
        FONT = "Pixel"
    
    state = {"karakter": "Cya"}  # karakter yang sedang dipilih"
    
    stage = ft.Stack(width=W, height=H)
    page.add(ft.Container(content=stage, alignment=ft.alignment.center, expand=True))
    
    def lapisan(nama):
        return ft.Image(src=nama, width=W, height=H, fit=ft.ImageFit.FILL)
    def area_klik(kiri, atas, lebar, tinggi, klik):
        return ft.Container(left=kiri * K, top=atas * K, width=lebar * K, height=tinggi * K, on_click=klik)
    
    # ---------- LAYAR 1: HOME ----------
    def home(e=None):
        page.on_keyboard_event = None
        stage.controls = [ 
            lapisan("bg_bersih.png"),
            lapisan("judul.png"),
            lapisan("tombol_menu.png"),
            area_klik(755, 470, 350, 110, loading),
            area_klik(755, 615, 490, 110, tampil_karakter),
        ]
        page.update()
    
    # ---------- LAYAR 2:PILIH KARAKTER ----------
    def pilih(nama):
       def klik(e):
           state["karakter"] = nama
           tampil_karakter()
       return klik
    def tampil_karakter(e=None):
        if state["karakter"] == "Bero":
            gambar_bero = "bero_dipilih.png"
        else:
            gambar_bero = "bero_normal.png"
            
        if state["karakter"] == "Cya":
            gambar_cya = "cya_dipilih.png"
        else:
            gambar_cya = "cya_normal.png"
        stage.controls = [
            lapisan("bg_bersih.png"),
            lapisan("judul_karakter.png"),
            lapisan("atau.png"),
            lapisan(gambar_bero),
            lapisan(gambar_cya),
            lapisan("tombol_x.png"),
            area_klik(245, 345, 525, 655, pilih("Bero")),
            area_klik(1150, 345, 530, 655, pilih("Cya")),
            area_klik(30, 33, 78, 78, home),
        ]
        page.update()
     # ---------- LAYAR 3:LOADING ----------
    def teks_garis(isi, ukuran, lebar):
        geser = [(-GARIS, -GARIS), (0, -GARIS), (GARIS, -GARIS),
                 (-GARIS, 0), (GARIS, 0),
                 (-GARIS, GARIS), (0, GARIS), (GARIS, GARIS)]
        daftar = []
        for dx, dy in geser:
            daftar.append(ft.Text(isi, size=ukuran, color="black", font_family=FONT,
                                  left=GARIS + dx, top=GARIS + dy))
        daftar.append(ft.Text(isi, size=ukuran, color="white", font_family=FONT,
                              left=GARIS, top=GARIS))
        kotak = ft.Stack(daftar, width=lebar, height=ukuran + 2 * GARIS + 6)
        return kotak, daftar 
    
    async def loading(e=None):
# ===== A. BUAT OBJEK (batang, karakter, teks) =====
        tiga_tips = random.sample(TIPS, 3)
        batang = []
        for n in range(JUMLAH_BATANG):
            kiri = BATANG_KIRI + n * JARAK_BATANG 
            batang.append(ft.Image(src="batang_hijau.png", left=kiri * K, 
                                   top=BATANG_ATAS * K, width=BATANG_LEBAR * K, height=BATANG_TINGGI * K, 
                                   fit=ft.ImageFit.FILL, visible=False))
        nama = state["karakter"].lower()
        tengah_awal = BATANG_KIRI + BATANG_LEBAR / 2 - JARAK_BATANG
        karakter = ft.Image(src=f"loading_{nama}.png",
                            left=(tengah_awal - SPRITE /2) * K, top=SPRITE_ATAS * K,
                            width=SPRITE * K, height=SPRITE * K,
                            animate_position=100)
        kotak_tips, daftar_tips = teks_garis(tiga_tips[0], UKURAN_TIPS, 860)
            

        # ===== B. TAMPILAN LAYAR =====
        stage.controls = [
            lapisan("bg_loading.png"),
            lapisan("bingkai_loading.png"),
            *batang, 
            karakter,
            lapisan("kolom_tips.png"),
            ft.Container(content=kotak_tips, 
                         left=TIPS_KIRI * K, 
                         top=TIPS_TENGAH_Y * K - (UKURAN_TIPS * 0.6 + GARIS))
        ]
        page.update()
       
        # garis waktu: 60 langkah * 0,1 detik = 6 detik
        langkah = int(DURASI * 10)        # 60 langkah, masing-masing 0,1 detik
        for k in range(1, langkah + 1):
            p = k / langkah               # kemajuan dari 0 sampai 1
            
            terisi = round(p * JUMLAH_BATANG) #jumlah batang yang sudah hijau
            for n in range(JUMLAH_BATANG):
                batang[n].visible = n < terisi
                
            tengah = BATANG_KIRI + BATANG_LEBAR / 2 + (p * JUMLAH_BATANG - 1) * JARAK_BATANG
            karakter.left = (tengah - SPRITE / 2) * K
             
            tip = tiga_tips[(k - 1) // 20] #ganti tips tiap 2 detik
            for t in daftar_tips:
                t.value = tip
                
            page.update()
            await asyncio.sleep(0.1)
            
        await asyncio.sleep(0.5)
        game()

    # ---------- LAYAR 4: GAME ROOM 1 ----------
    def game():
        penghalang = muat_penghalang()
        nama = state["karakter"].lower()
        pos = {"x": float(KAR_MULAI[0]), "y": float(KAR_MULAI[1]), "laptop": False}
 
        def tabrakan(x, y):
            """True bila kaki karakter di (x, y) menabrak benda atau keluar dari lantai."""
            kiri, kanan = x - KAKI_LEBAR / 2, x + KAKI_LEBAR / 2
            atas, bawah = y - KAKI_TINGGI, y
            if kiri < LANTAI[0] or kanan > LANTAI[2] or atas < LANTAI[1] or bawah > LANTAI[3]:
                return True
            for l, a, r, b in penghalang:
                if kiri < r and kanan > l and atas < b and bawah > a:
                    return True
            return False
 
        # bila posisi awal menabrak sesuatu, cari tempat kosong terdekat
        if tabrakan(pos["x"], pos["y"]):
            terbaik = None
            for dy in range(-500, 501, 20):
                for dx in range(-800, 801, 20):
                    x, y = KAR_MULAI[0] + dx, KAR_MULAI[1] + dy
                    if not tabrakan(x, y):
                        jarak = dx * dx + dy * dy
                        if terbaik is None or jarak < terbaik[0]:
                            terbaik = (jarak, x, y)
            if terbaik:
                pos["x"], pos["y"] = terbaik[1], terbaik[2]
 
        karakter = ft.Image(src=f"loading_{nama}.png", width=KAR_UKURAN * K, height=KAR_UKURAN * K,
                            fit=ft.ImageFit.CONTAIN)
        bayangan = ft.Container(width=BAYANG_LEBAR * K, height=BAYANG_TINGGI * K,
                                bgcolor="#66000000", border_radius=BAYANG_LEBAR)
 
        def taruh_karakter():
            karakter.left = (pos["x"] - KAR_UKURAN / 2) * K
            karakter.top = (pos["y"] - KAR_UKURAN) * K
            bayangan.left = (pos["x"] - BAYANG_LEBAR / 2) * K
            bayangan.top = (pos["y"] - BAYANG_TINGGI / 2 - BAYANG_GESER) * K
        taruh_karakter()

        # tulisan "Tekan E" yang muncul saat dekat laptop
        petunjuk = ft.Container(
            content=ft.Text("Tekan E untuk membuka laptop", font_family=FONT, size=10, color="white"),
            bgcolor="#CC000000", border=ft.border.all(2, "white"), border_radius=8,
            padding=8, left=W / 2 - 170, top=16, width=340, alignment=ft.alignment.center,
            visible=False)
        
        # ---------- LAPTOP: DESKTOP -> JIMAIL -> EMAIL -> HASIL ----------
        mode = {"layar": None}
        hasil_email = {}                       # nomor email -> True bila jawaban pemain benar
        layar_laptop = ft.Stack(width=W, height=H, visible=False)
 
        def tx(isi, ukuran=8, warna=J_TEKS, **kw):
            return ft.Text(isi, size=ukuran, color=warna, font_family=FONT, **kw)
 
        def pasang(daftar):
            layar_laptop.controls = daftar
            page.update()
 
        # jam real-time di taskbar (menutupi jam bawaan di gambar desktop)
        kotak_jam, daftar_jam = teks_garis(jam_sekarang(), 14, 8 * 14 + 2 * GARIS + 4)
        pil_jam = ft.Container(content=kotak_jam, left=JAM[0] * K, top=JAM[1] * K,
                               width=JAM[2] * K, height=JAM[3] * K, bgcolor="#6FD35B",
                               border=ft.border.all(2, "black"), border_radius=24,
                               alignment=ft.alignment.center)
 
        def tampil_desktop():
            mode["layar"] = "desktop"
            for tt in daftar_jam:
                tt.value = jam_sekarang()
            pasang([
                lapisan(FILE_DESKTOP),
                area_klik(*ICON_JIMAIL, lambda e: tampil_inbox()),
                pil_jam,
                ft.Container(content=tx("Esc = tutup laptop", 8, "white"), right=10, top=8,
                             bgcolor="#88000000", padding=6),
            ])
 
        def tampil_inbox():
            mode["layar"] = "inbox"
            item = [
                ft.Container(width=W, height=H, bgcolor=J_BG),
                ft.Container(width=W - 160, height=H - 60, left=150, top=50, bgcolor=J_PANEL,
                             border=ft.border.all(2, J_GARIS), border_radius=10),
                tx("=", 14, J_TEKS, left=12, top=12),
                tx("Jimail", 11, J_TEKS, left=44, top=14),
                ft.Container(content=tx("Telusuri jimail", 8, J_ABU), left=150, top=8, width=560, height=30,
                             bgcolor=J_PANEL, border=ft.border.all(2, J_GARIS), border_radius=14,
                             padding=ft.padding.only(left=14, top=9)),
                ft.Container(content=tx("X", 10, "white"), right=12, top=8, padding=8, bgcolor=J_AKTIF,
                             border_radius=6, on_click=lambda e: tampil_desktop()),
                ft.Container(content=tx("Tulis", 8, J_TEKS), left=8, top=52, width=120, height=36,
                             border=ft.border.all(2, J_GARIS), border_radius=10,
                             alignment=ft.alignment.center),
            ]
            menu = ["Kotak Masuk", "Berbintang", "Ditunda", "Terkirim", "Draf", "Pembelian", "Selengkapnya"]
            for n, nama_menu in enumerate(menu):
                item.append(ft.Container(content=tx(nama_menu, 7, J_TEKS), left=0, top=100 + n * 26,
                                         width=140, height=24, border_radius=6,
                                         bgcolor=J_AKTIF if n == 0 else None,
                                         padding=ft.padding.only(left=14, top=8)))
            for n, tab in enumerate(["Utama", "Promosi", "Sosial", "Info Terbaru"]):
                item.append(tx(tab, 8, "#7FA0FF" if n == 0 else J_ABU, left=170 + n * 150, top=76))
            item.append(ft.Container(left=160, top=96, width=100, height=3, bgcolor="#7FA0FF"))
            item.append(ft.Container(left=152, top=102, width=W - 164, height=2, bgcolor=J_GARIS))
            for i, em in enumerate(EMAIL):
                if i in hasil_email:
                    penanda = ("BENAR", "#5FE08A") if hasil_email[i] else ("SALAH", "#FF7A7A")
                else:
                    penanda = ("", J_ABU)
                baris = ft.Row([
                    ft.Container(width=12, height=12, border=ft.border.all(2, J_ABU)),
                    tx("*", 10, J_ABU),
                    ft.Container(tx(em["nama"], 8, J_TEKS, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS), width=180),
                    ft.Container(tx(em["subjek"], 8, J_ABU, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS), width=400),
                    tx(em["waktu"], 8, J_ABU),
                    tx(penanda[0], 7, penanda[1]),
                ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER)
                item.append(ft.Container(content=baris, left=152, top=108 + i * 40, width=W - 164, height=38,
                                         padding=ft.padding.only(left=14),
                                         border=ft.border.only(bottom=ft.BorderSide(2, J_GARIS)),
                                         on_click=lambda e, n=i: tampil_email(n)))
            item.append(tx("2% dari 15 GB digunakan", 6, J_ABU, left=14, bottom=12))
            pasang(item)
 
        def tampil_email(i):
            mode["layar"] = "email"
            em = EMAIL[i]
            isi = em["isi"].replace("[Nama Pemain]", state["karakter"])
 
            def tombol(label, warna, jawab_phishing):
                return ft.Container(content=tx(label, 9, "white"), bgcolor=warna,
                                    border=ft.border.all(2, "white"), border_radius=6,
                                    padding=ft.padding.symmetric(horizontal=18, vertical=12),
                                    on_click=lambda e: tampil_hasil(i, jawab_phishing))
 
            kolom = [ft.Container(content=tx(isi, 9, J_TEKS), width=W - 220)]
            if em["tautan"]:
                kolom.append(tx(em["tautan"], 9, "#7FA0FF"))
                kolom.append(tx("Tautan menuju: " + em["tujuan"], 7, J_ABU))
            kolom.append(ft.Container(height=6))
            kolom.append(ft.Row([tombol("PHISHING", "#B3312F", True),
                                 tombol("SAFE", "#2E8B57", False)], spacing=20))
            pasang([
                ft.Container(width=W, height=H, bgcolor=J_BG),
                ft.Container(width=W - 160, height=H - 60, left=150, top=50, bgcolor=J_PANEL,
                             border=ft.border.all(2, J_GARIS), border_radius=10),
                ft.Container(content=tx("<-", 12, J_TEKS), left=162, top=60, padding=8,
                             on_click=lambda e: tampil_inbox()),
                tx(em["subjek"], 10, J_TEKS, left=176, top=104),
                tx("[ Kotak Masuk ]", 6, J_ABU, left=176, top=124),
                ft.Container(content=tx(em["nama"][0], 12, "white"), left=176, top=146, width=36, height=36,
                             border_radius=18, bgcolor="#7E57C2", alignment=ft.alignment.center),
                tx(em["nama"], 9, J_TEKS, left=224, top=148),
                tx("<" + em["alamat"] + ">", 7, J_ABU, left=224, top=164),
                tx("kepada saya", 7, J_ABU, left=224, top=178),
                tx(em["waktu"] + " (hari ini)", 7, J_ABU, right=30, top=150),
                ft.Column(kolom, left=176, top=208, width=W - 220, spacing=14),
            ])
 
        def tampil_hasil(i, jawab_phishing):
            # TODO: desain halaman benar/salah dari kalian menyusul; ganti isi pasang([...]) di bawah ini.
            mode["layar"] = "hasil"
            em = EMAIL[i]
            benar = (jawab_phishing == em["phishing"])
            hasil_email[i] = benar
            warna = "#5FE08A" if benar else "#FF7A7A"
            kolom = [
                tx("JAWABAN BENAR!" if benar else "JAWABAN SALAH!", 16, warna),
                tx("Email ini adalah: " + ("PHISHING" if em["phishing"] else "SAFE"), 9, J_TEKS),
                tx("Alasannya:", 9, J_ABU),
            ]
            for a in em["alasan"]:
                kolom.append(ft.Container(content=tx("- " + a, 8, J_TEKS), width=W - 260))
            kolom.append(ft.Container(content=tx("KEMBALI KE KOTAK MASUK", 9, "white"), bgcolor=J_AKTIF,
                                      border=ft.border.all(2, "white"), border_radius=6,
                                      padding=ft.padding.symmetric(horizontal=18, vertical=12),
                                      on_click=lambda e: tampil_inbox()))
            pasang([
                ft.Container(width=W, height=H, bgcolor=J_BG),
                ft.Container(width=W - 160, height=H - 60, left=150, top=50, bgcolor=J_PANEL,
                             border=ft.border.all(3, warna), border_radius=10),
                ft.Column(kolom, left=190, top=90, width=W - 260, spacing=18),
            ])
 
        async def jam_loop():
            """Memperbarui jam di desktop laptop setiap detik."""
            while karakter in stage.controls:
                if layar_laptop.visible and mode["layar"] == "desktop":
                    try:
                        for tt in daftar_jam:
                            tt.value = jam_sekarang()
                        kotak_jam.update()
                    except Exception:
                        pass
                await asyncio.sleep(1)
 
        # kotak penolong untuk melihat area tabrakan (DEBUG_KOTAK)
        debug = []
        if DEBUG_KOTAK:
            def kotak(l, a, r, b, warna, isi=None):
                return ft.Container(left=l * K, top=a * K, width=(r - l) * K, height=(b - a) * K,
                                    border=ft.border.all(2, warna), bgcolor=isi)
            debug.append(kotak(*LANTAI, "yellow"))
            debug.append(kotak(*AREA_LAPTOP, "cyan"))
            for l, a, r, b in penghalang:
                debug.append(kotak(l, a, r, b, "red", "#55FF0000"))
 
        def dekat_laptop():
            l, a, r, b = AREA_LAPTOP
            return (l - JARAK_LAPTOP <= pos["x"] <= r + JARAK_LAPTOP
                    and a - JARAK_LAPTOP <= pos["y"] <= b + JARAK_LAPTOP)
 
        def segarkan():
            petunjuk.visible = (not pos["laptop"]) and dekat_laptop()
            page.update()
 
        def buka_laptop():
            if dekat_laptop() and not pos["laptop"]:
                pos["laptop"] = True
                petunjuk.visible = False
                layar_laptop.visible = True
                tampil_desktop()          # menampilkan desktop laptop (lalu Jimail dan email)

        def tutup_laptop():
            pos["laptop"] = False
            layar_laptop.visible = False
            mode["layar"] = None
            segarkan()
 
        ARAH = {"arrow left": (-1, 0), "arrow right": (1, 0), "arrow up": (0, -1), "arrow down": (0, 1),
                "a": (-1, 0), "d": (1, 0), "w": (0, -1), "s": (0, 1)}
 
        tahan = {"tombol": None, "terakhir": 0.0, "ulang": False}

        def gerak(dx, dy, jarak):
            """Geser karakter sejauh 'jarak', per 4 piksel supaya rapat ke benda."""
            sisa = jarak
            while sisa > 0:
                s = min(4, sisa)
                if tabrakan(pos["x"] + dx * s, pos["y"] + dy * s):
                    break
                pos["x"] += dx * s
                pos["y"] += dy * s
                sisa -= s

        def perbarui_petunjuk():
            tampil = (not pos["laptop"]) and dekat_laptop()
            if petunjuk.visible != tampil:
                petunjuk.visible = tampil
                petunjuk.update()

        async def loop_gerak():
            """Satu loop yang berjalan terus: menggerakkan karakter selama tombol arah masih aktif."""
            waktu_lalu = time.monotonic()
            while karakter in stage.controls:
                await asyncio.sleep(1 / 60)
                sekarang = time.monotonic()
                dt = min(sekarang - waktu_lalu, 0.05)     # dibatasi agar tidak melompat saat lag
                waktu_lalu = sekarang
                k = tahan["tombol"]
                if k is None or pos["laptop"]:
                    continue
                batas = LEPAS_DETIK if tahan["ulang"] else AWAL_DETIK
                if sekarang - tahan["terakhir"] > batas:  # tombol dianggap dilepas
                    tahan["tombol"] = None
                    perbarui_petunjuk()
                    continue
                dx, dy = ARAH[k]
                gerak(dx, dy, KECEPATAN * dt)
                taruh_karakter()
                bayangan.update()
                karakter.update()
                perbarui_petunjuk()

        async def on_key(e: ft.KeyboardEvent):
            k = e.key.lower()
            if pos["laptop"]:                             # saat laptop terbuka, karakter diam
                if k == "escape":
                    tutup_laptop()
                return
            if k in ARAH:
                t = time.monotonic()
                if tahan["tombol"] == k and t - tahan["terakhir"] < JEDA_TAHAN:
                    tahan["terakhir"] = t                 # sinyal ulang: tombol sedang ditahan
                    tahan["ulang"] = True
                else:                                     # tekan baru (atau ganti arah)
                    tahan.update(tombol=k, terakhir=t, ulang=False)
            elif k in TOMBOL_BUKA:
                buka_laptop()
        page.on_keyboard_event = on_key
 
        teks_monolog = ft.Text(value="", font_family=FONT, size=11, color="white")
        kotak_monolog = ft.Container(
            content=teks_monolog, bgcolor="#CC000000", border=ft.border.all(2, "white"),
            border_radius=10, padding=15, width=W - 40, height=120, bottom=20, left=20)
 
        stage.controls = [
            lapisan(f"{RUANG}/bg_polos_room1.png"),
 
            # dinding belakang
            lapisan(f"{RUANG}/papan_tulis_room1.png"),
            lapisan(f"{RUANG}/mading_room1.png"),
            lapisan(f"{RUANG}/pintu_tertutup_room1.png"),
 
            # sisi kiri
            lapisan(f"{RUANG}/kardus_room1.png"),
            lapisan(f"{RUANG}/rak_buku_room1.png"),
 
            # tengah
            lapisan(f"{RUANG}/pot_bunga_room1.png"),
            lapisan(f"{RUANG}/meja_depan_room1.png"),
            lapisan(f"{RUANG}/laptop_room1.png"),
 
            bayangan,                                   # bayangan di bawah karakter
            karakter,                                   # karakter di atas benda tengah, di bawah meja terdepan
            lapisan(f"{RUANG}/3meja_room1.png"),        # paling depan
 
            *debug,
            area_klik(1250, 365, 200, 190, lambda e: buka_laptop()),   # klik laptop (hanya bila dekat)
            petunjuk,
            kotak_monolog,
            layar_laptop,
        ]
        page.update()
        asyncio.create_task(loop_gerak())
        asyncio.create_task(jam_loop())
 
        async def animasi_monolog():
            cerita_utuh = ("Sekarang kamu berada di sebuah gedung, kamu terjebak di ruangan ini, "
                           "kamu harus menyelesaikan masalah yang ada di komputer ruangan ini agar bisa "
                           "lanjut ke ruangan selanjutnya, lakukan hingga ruangan terakhir agar bisa "
                           "keluar dari gedung ini. Good luck!")
            teks_berjalan = ""
            for huruf in cerita_utuh:
                teks_berjalan += huruf
                teks_monolog.value = teks_berjalan
                page.update()
                await asyncio.sleep(0.04)
            await asyncio.sleep(5.0)
            kotak_monolog.visible = False
            page.update()
 
        asyncio.create_task(animasi_monolog())

    home()

ft.app(target=main, view=ft.AppView.WEB_BROWSER, assets_dir="assets")
