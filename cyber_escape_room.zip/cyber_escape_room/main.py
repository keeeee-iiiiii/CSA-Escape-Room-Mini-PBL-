import asyncio
import random
import flet as ft

W, H = 960, 540 # ukuran layar game (pixel)
K = 0.5         # skala: koordinat desain 1920x1080 menjadi layar 960x540
# Ubah ke True setelah file font ditaruh di assets/fonts
PAKAI_FONT = False

TIPS = [
    "Jangan pernah membagikan kode OTP kepada siapa pun.", 
    "Gunakan password panjang dan unik untuk setiap akun.", 
    "Periksa alamat pengirim sebelum mengeklik tautan di email atau pesan.", 
    "Bandingkan hash file unduhan dengan hash resmi untuk memastikan file tidak berubah.", 
    "Jika perangkatmu terkena serangan, segera putuskan dari jaringan dan laporkan.", 
    "Cek izin aplikasi. Tolak izin yang tidak sesuai dengan fungsinya.", 
    "Aktifkan verifikasi dua langkah (MFA) agar akunmu lebih aman.", 
    "Pesan yang membuatmu panik dan menyuruh bertindak cepat sering kali phishing.", 
    "Batasi permission file penting agar tidak sembarang orang bisa mengubahnya.",
    "Catat kronologi insiden. Itu bahan evaluasi agar kejadian serupa tidak terulang.",
 ]

DURASI = 6.0                           # lama loading (detik)
JUMLAH_BATANG = 16                     # jumlah batang hijau di dalam bingkai
BATANG_KIRI, BATANG_ATAS = 512,543        
BATANG_LEBAR, BATANG_TINGGI = 48, 64
JARAK_BATANG = 58.2                    # jarang dari satu batang ke batang berikutnya
SPRITE, SPRITE_ATAS = 110, 412         # ukuran dan tinggi karakter kecil
TIPS_KIRI, TIPS_TENGAH_Y = 200, 1032   # posisi teks tips
GARIS = 2                              # tebal garis hitam di pinggir teks tips


def main(page: ft.Page):
    page.title = "Cybersecurity Awareness Escape Room"
    page.bgcolor = "black"
    page.padding = 0
    
    FONT = None
    if PAKAI_FONT:
        page.fonts = {"Pixel": "fonts/PressStart2P-Regular.ttf"}
        FONT = "Pixel"
    
    state = {"karakter": "Cya"}  # karakter yang sedang dipilih"
    
    stage = ft.Stack(width=W, height=H)
    page.add(ft.Container(content=stage, alignment=ft.alignment.center, expand=True))
    
    def lapisan(nama):
        return ft.Image(src=nama, width=W, height=H, fit=ft.ImageFit.FILL)
    def area_klik(kiri, atas, lebar, tinggi, klik):
        return ft.Container(left=kiri * K, top=atas * K, width=lebar * K, height=tinggi * K, on_click=klik)
    
    # ---------- LAYAR 1: HOME ----------
    def home(e=None):
        stage.controls = [ 
            lapisan("bg_bersih.png"),
            lapisan("judul.png"),
            lapisan("tombol_menu.png"),
            area_klik(755, 470, 350, 110, loading),
            area_klik(755, 615, 490, 110, tampil_karakter),
        ]
        page.update()
    
    # ---------- LAYAR 2:PILIH KARAKTER ----------
    def pilih(nama):
       def klik(e):
           state["karakter"] = nama
           tampil_karakter()
       return klik
    def tampil_karakter(e=None):
        if state["karakter"] == "Bero":
            gambar_bero = "bero_dipilih.png"
        else:
            gambar_bero = "bero_normal.png"
            
        if state["karakter"] == "Cya":
            gambar_cya = "cya_dipilih.png"
        else:
            gambar_cya = "cya_normal.png"
        stage.controls = [
            lapisan("bg_bersih.png"),
            lapisan("judul_karakter.png"),
            lapisan("atau.png"),
            lapisan(gambar_bero),
            lapisan(gambar_cya),
            lapisan("tombol_x.png"),
            area_klik(245, 345, 525, 655, pilih("Bero")),
            area_klik(1150, 345, 530, 655, pilih("Cya")),
            area_klik(30, 33, 78, 78, home),
        ]
        page.update()
     # ---------- LAYAR 3:LOADING ----------
    
    def teks_garis(isi, ukuran, lebar):
        geser = [(-GARIS, -GARIS), (0, -GARIS), (GARIS, -GARIS),
                 (-GARIS, 0), (GARIS, 0),
                 (-GARIS, GARIS), (0, GARIS), (GARIS, GARIS)] 
        daftar = [] 
        for dx, dy in geser: 
            daftar.append(ft.Text(isi, size=ukuran, color="black", font_family=FONT, left=GARIS + dx, top=GARIS + dy)) 
            daftar.append(ft.Text(isi, size=ukuran, color="white", font_family=FONT,
                          left=GARIS, top=GARIS)) 
            kotak = ft.Stack(daftar, width=lebar, height=ukuran + 2 * GARIS + 6) 
            return kotak, daftar 
    async def loading(e=None):
# ===== A. BUAT OBJEK (batang, karakter, teks) =====
        tiga_tips = random.sample(TIPS, 3)
        batang = []
        for n in range(JUMLAH_BATANG):
            kiri = BATANG_KIRI + n * JARAK_BATANG 
            batang.append(ft.Image(src="batang_hijau.png", left=kiri * K, 
                                   top=BATANG_ATAS * K, width=BATANG_LEBAR * K, height=BATANG_TINGGI * K, 
                                   fit=ft.ImageFit.FILL, visible=False))
        nama = state["karakter"].lower()
        tengah_awal = BATANG_KIRI + BATANG_LEBAR / 2 - JARAK_BATANG
        karakter = ft.Image(src=f"loading_{nama}.png",
                            left=(tengah_awal - SPRITE /2) * K, top=SPRITE_ATAS * K,
                            width=SPRITE * K, height=SPRITE * K,
                            animate_position=100)
        kotak_tips, daftar_tips = teks_garis(tiga_tips[0], 14, 860)
            

        # ===== B. TAMPILAN LAYAR =====
        stage.controls = [
            lapisan("bg_loading.png"),
            lapisan("bingkai_loading.png"),
            *batang, 
            karakter,
            lapisan("kolom_tips.png"),
            ft.Container(content=kotak_tips,
                         left=TIPS_KIRI * K, top=TIPS_TENGAH_Y * K - 12)
        ]
        page.update()
       
        # garis waktu: 60 langkah * 0,1 detik = 6 detik
        langkah = int(DURASI * 10)        # 60 langkah, masing-masing 0,1 detik
        for k in range(1, langkah + 1):
            p = k / langkah               # kemajuan dari 0 sampai 1
            
            terisi = round(p * JUMLAH_BATANG) #jumlah batang yang sudah hijau
            for n in range(JUMLAH_BATANG):
                batang[n].visible = n < terisi
                
            tengah = BATANG_KIRI + BATANG_LEBAR / 2 + (p * JUMLAH_BATANG - 1) * JARAK_BATANG
            karakter.left = (tengah - SPRITE / 2) * K
             
            tip = tiga_tips[(k - 1) // 20] #ganti tips tiap 2 detik
            for t in daftar_tips:
                t.value = tip
                
            page.update()
            await asyncio.sleep(0.1)
            
        await asyncio.sleep(0.5)
        game()
        
# ---------- LAYAR GAME (SEMENTARA) ----------
    def game(): 
        stage.controls = [
            lapisan("bg_loading.png"),
            ft.Container(
                content=ft.Column([
                    ft.Text("Room 1 menyusul...", size=22, color="white"),
                    ft.ElevatedButton("Back to menu", on_click=home),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=12),
                bgcolor="#AA000000", border_radius=16, padding=24,
                left=(W - 320) / 2, top=170, width=320),
        ]
        page.update()
            
    home()

ft.app(target=main, view=ft.AppView.WEB_BROWSER, assets_dir="assets")
